import fs from 'fs';

const html = fs.readFileSync('/tmp/sara_isaac.html', 'utf8');

console.log('--- CSS VARIABLES ---');
const rootMatch = html.match(/:root\s*\{([^}]+)\}/);
if (rootMatch) console.log(rootMatch[1].trim());

console.log('--- FONTS ---');
const fonts = [...html.matchAll(/family=([^&"'\s]+)/g)].map(m => m[1]);
console.log([...new Set(fonts)]);

console.log('--- SECTION IDS & HEADINGS ---');
const ids = [...html.matchAll(/id="([^"]+)"/g)].map(m => m[1]);
console.log('Unique IDs:', [...new Set(ids)]);

const headings = [...html.matchAll(/<(h[1-6])[^>]*>([\s\S]*?)<\/\1>/gi)].map(m => `${m[1]}: ${m[2].replace(/<[^>]+>/g, '').trim()}`);
console.log('Headings:', headings);

// Find audio source
const audioMatches = [...html.matchAll(/<audio[^>]*src="([^"]+)"/g)].map(m => m[1]);
console.log('Audio sources:', audioMatches);
const mp3Matches = [...html.matchAll(/(https?:\/\/[^"'\s]+\.mp3)/g)].map(m => m[1]);
console.log('MP3 URLs:', [...new Set(mp3Matches)]);
