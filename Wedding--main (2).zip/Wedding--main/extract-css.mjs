import fs from 'fs';

const html = fs.readFileSync('/tmp/sara_isaac.html', 'utf8');

// Extract all <style> contents
const styleMatch = html.match(/<style>([\s\S]*?)<\/style>/);
if (styleMatch) {
  const css = styleMatch[1];
  console.log('CSS length:', css.length);
  // Let's search for classes: .landing, .invite, .mono, .family, .dress, .gallery, .rsvp, .wishes, .footer
  fs.writeFileSync('/tmp/sara_isaac.css', css);
  console.log('Saved CSS to /tmp/sara_isaac.css');
}
