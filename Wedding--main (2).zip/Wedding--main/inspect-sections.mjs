import fs from 'fs';

const html = fs.readFileSync('/tmp/sara_isaac.html', 'utf8');

// Print the landing inner HTML
const landingMatch = html.match(/<div class="landing-inner"[\s\S]*?<\/div>\s*<\/div>/);
if (landingMatch) {
  console.log('=== LANDING HTML ===');
  console.log(landingMatch[0].slice(0, 1500));
}

// Print main content outline
const mainMatch = html.match(/<main id="main"[\s\S]*?<\/main>/);
if (mainMatch) {
  console.log('=== MAIN HTML OUTLINE ===');
  const sections = [...mainMatch[0].matchAll(/<(section|div)[^>]*(class|id)="([^"]*)"[^>]*>/g)];
  console.log(sections.map(s => `<${s[1]} ${s[2]}="${s[3]}">`).slice(0, 50));
}
