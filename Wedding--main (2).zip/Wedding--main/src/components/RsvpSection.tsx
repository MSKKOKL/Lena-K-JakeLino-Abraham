import React, { useState, useEffect } from 'react';
import { Send, CheckCircle2, MessageSquare } from 'lucide-react';
import confetti from 'canvas-confetti';
import { doc, setDoc } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import { RsvpEntry } from '../types';
import { AdminPortal } from './AdminPortal';

export const RsvpSection: React.FC = () => {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [side, setSide] = useState<'groom' | 'bride'>('groom');
  const [attendingStatus, setAttendingStatus] = useState<'attending' | 'declined'>('attending');
  const [attendingCeremony, setAttendingCeremony] = useState(true);
  const [attendingReception, setAttendingReception] = useState(true);
  const [guestCount, setGuestCount] = useState(2);
  const [note, setNote] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submittedRsvp, setSubmittedRsvp] = useState<RsvpEntry | null>(null);

  useEffect(() => {
    try {
      const saved = localStorage.getItem('blesson_glinta_rsvp');
      if (saved) {
        setSubmittedRsvp(JSON.parse(saved));
      }
    } catch {
      // ignore
    }
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setError('Please enter your full name.');
      return;
    }
    if (!phone.trim()) {
      setError('Please enter your WhatsApp contact number.');
      return;
    }

    setError(null);
    setIsSubmitting(true);
    const docId = `rsvp-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
    const newEntry: RsvpEntry = {
      id: docId,
      fullName: name.trim(),
      whatsapp: phone.trim(),
      side,
      attendingCeremony: attendingStatus === 'attending' ? attendingCeremony : false,
      attendingReception: attendingStatus === 'attending' ? attendingReception : false,
      guestCount: attendingStatus === 'attending' ? guestCount : 0,
      message: note.trim(),
      createdAt: new Date().toISOString(),
    };

    // Save locally
    try {
      localStorage.setItem('blesson_glinta_rsvp', JSON.stringify(newEntry));
      const savedList = localStorage.getItem('blesson_glinta_all_rsvps');
      const allRsvps: RsvpEntry[] = savedList ? JSON.parse(savedList) : [];
      const updatedList = [newEntry, ...allRsvps.filter((r) => r.whatsapp !== newEntry.whatsapp)];
      localStorage.setItem('blesson_glinta_all_rsvps', JSON.stringify(updatedList));
    } catch {
      // ignore
    }

    // Save to Firestore
    try {
      await setDoc(doc(db, 'rsvps', docId), {
        name: name.trim(),
        phone: phone.trim(),
        side,
        attending: attendingStatus === 'attending' ? 'yes' : 'no',
        guestsCount: attendingStatus === 'attending' ? Number(guestCount) : 0,
        attendingCeremony: attendingStatus === 'attending' ? Boolean(attendingCeremony) : false,
        attendingReception: attendingStatus === 'attending' ? Boolean(attendingReception) : false,
        dietary: '',
        message: note.trim(),
        createdAt: new Date().toISOString(),
      });
    } catch (err) {
      console.warn('Error writing RSVP to Firestore:', err);
      try {
        handleFirestoreError(err, OperationType.WRITE, `rsvps/${docId}`);
      } catch {
        // Logged
      }
    } finally {
      setIsSubmitting(false);
    }

    setSubmittedRsvp(newEntry);

    // Launch celebration confetti
    confetti({
      particleCount: 55,
      spread: 75,
      origin: { y: 0.65 },
      colors: ['#2b4635', '#a07820', '#7d2233', '#ffffff'],
    });
  };

  const handleEditRsvp = () => {
    if (submittedRsvp) {
      setName(submittedRsvp.fullName);
      setPhone(submittedRsvp.whatsapp);
      setSide(submittedRsvp.side);
      setAttendingCeremony(submittedRsvp.attendingCeremony);
      setAttendingReception(submittedRsvp.attendingReception);
      setGuestCount(submittedRsvp.guestCount || 2);
      setNote(submittedRsvp.message || '');
      setAttendingStatus(submittedRsvp.guestCount > 0 ? 'attending' : 'declined');
    }
    setSubmittedRsvp(null);
  };

  const getWhatsAppShareLink = (phoneNum: string = '919072256228') => {
    if (!submittedRsvp) return '#';
    const text = encodeURIComponent(
      `Hello Blesson & Glinta! 🤍\n` +
      `RSVP for Wedding of Blesson & Glinta:\n` +
      `• Guest Name: ${submittedRsvp.fullName}\n` +
      `• Attending: ${submittedRsvp.guestCount > 0 ? 'Yes, with joy' : 'Respectfully unable to attend'}\n` +
      `• Side: ${submittedRsvp.side === 'bride' ? "Bride's Family" : "Groom's Family"}\n` +
      `• Total Guests: ${submittedRsvp.guestCount}\n` +
      (submittedRsvp.message ? `• Note: "${submittedRsvp.message}"\n` : '') +
      `Venue: Stay Samara, Kottayam, Kerala (Dec 7, 2026)`
    );
    return `https://wa.me/${phoneNum}?text=${text}`;
  };

  return (
    <section className="rsvp py-16 px-5 sm:px-8 text-center relative border-b border-[rgba(160,120,32,0.25)]">
      <div className="max-w-xl mx-auto">
        <div className="section-eyebrow">— YOUR PRESENCE —</div>
        <h2 className="section-title">RSVP</h2>

        <p className="font-cormorant italic text-[18.5px] text-[#5b6840] font-semibold max-w-md mx-auto mb-6 leading-relaxed">
          Your love, prayers, and gracious presence are the greatest gifts to our new beginning.
        </p>

        <div className="divider mb-8">
          <span />
          <div className="dot" />
          <span />
        </div>

        {submittedRsvp ? (
          <div className="sara-card p-7 sm:p-8 text-center max-w-lg mx-auto">
            <div className="w-14 h-14 rounded-full bg-[#2b4635]/10 text-[#2b4635] flex items-center justify-center mx-auto mb-4 border border-[#2b4635]/25">
              <CheckCircle2 className="w-8 h-8" />
            </div>

            <h3 className="font-italiana text-2xl text-[#2b4635] mb-2">
              Thank You, {submittedRsvp.fullName}!
            </h3>

            <p className="font-cormorant italic text-[17px] text-[#5b6840] max-w-sm mx-auto mb-6">
              {submittedRsvp.guestCount > 0
                ? "Your response has been saved. We are thrilled to celebrate our Holy Wedding day with you at Stay Samara!"
                : "Your blessing has been noted with gratitude. We will miss having you in person."}
            </p>

            <div className="bg-[#faf5e9] p-4 rounded-xl border border-[rgba(160,120,32,0.2)] text-left text-[15px] font-cormorant text-[#2b4635] space-y-2 max-w-sm mx-auto mb-6">
              <div className="flex justify-between border-b border-[rgba(160,120,32,0.15)] pb-1.5">
                <span className="font-cinzel text-[8.5px] tracking-[0.2em] uppercase text-[#5b6840]">Guest Side</span>
                <span className="font-semibold capitalize">{submittedRsvp.side}'s Family</span>
              </div>
              <div className="flex justify-between border-b border-[rgba(160,120,32,0.15)] pb-1.5">
                <span className="font-cinzel text-[8.5px] tracking-[0.2em] uppercase text-[#5b6840]">Attendance</span>
                <span className="font-semibold text-[#2b4635]">
                  {submittedRsvp.guestCount > 0 ? `Attending (${submittedRsvp.guestCount} Guests)` : 'Declined'}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="font-cinzel text-[8.5px] tracking-[0.2em] uppercase text-[#5b6840]">Ceremony</span>
                <span className="font-semibold">Dec 7, 2026 &bull; 11:30 AM</span>
              </div>
            </div>

            <p className="font-cormorant italic text-[14.5px] text-[#5b6840] mb-3">
              Both contact numbers are active WhatsApp lines. Tap either button to share your RSVP:
            </p>

            <div className="flex flex-col sm:flex-row items-center justify-center gap-2.5">
              <a
                href={getWhatsAppShareLink('919072256228')}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-md bg-[#2b4635] hover:bg-[#3a5c46] text-[#faf5e9] font-cinzel text-[9.5px] tracking-[0.16em] transition-all shadow-md cursor-pointer"
              >
                <MessageSquare className="w-3.5 h-3.5 text-[#a07820]" />
                <span>WHATSAPP (+91 90722 56228)</span>
              </a>

              <a
                href={getWhatsAppShareLink('9539577574')}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-md bg-[#faf5e9] hover:bg-white text-[#2b4635] border border-[rgba(160,120,32,0.4)] font-cinzel text-[9.5px] tracking-[0.16em] transition-all shadow-sm cursor-pointer"
              >
                <MessageSquare className="w-3.5 h-3.5 text-[#2b4635]" />
                <span>WHATSAPP (+91 9539577574)</span>
              </a>
            </div>

            <div className="pt-2">
              <button
                onClick={handleEditRsvp}
                type="button"
                className="font-cinzel text-[9px] tracking-[0.2em] text-[#5b6840] hover:text-[#2b4635] underline underline-offset-4 py-1 cursor-pointer"
              >
                EDIT RESPONSE
              </button>
            </div>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="sara-card p-6 sm:p-8 text-left max-w-lg mx-auto space-y-6">
            {error && (
              <div className="p-3 rounded-md bg-red-50 border border-red-200 text-[#7d2233] text-xs font-cormorant text-center">
                {error}
              </div>
            )}

            {/* Attendance Toggle */}
            <div>
              <label className="font-cinzel text-[9px] tracking-[0.22em] text-[#2b4635] block mb-2 font-semibold">
                <span className="inline-block w-4 h-4 rounded-full bg-[#2b4635] text-[#faf5e9] text-center leading-4 text-[8.5px] mr-1.5">
                  1
                </span>
                ATTENDANCE
              </label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setAttendingStatus('attending')}
                  className={`py-3 px-3 rounded-md border font-cinzel text-[9.5px] tracking-[0.18em] transition-all cursor-pointer ${
                    attendingStatus === 'attending'
                      ? 'bg-[#2b4635] text-[#faf5e9] border-[#2b4635] shadow-sm font-semibold'
                      : 'bg-transparent text-[#2b4635] border-[rgba(43,70,53,0.2)] hover:border-[#2b4635]'
                  }`}
                >
                  ATTENDING WITH JOY
                </button>
                <button
                  type="button"
                  onClick={() => setAttendingStatus('declined')}
                  className={`py-3 px-3 rounded-md border font-cinzel text-[9.5px] tracking-[0.18em] transition-all cursor-pointer ${
                    attendingStatus === 'declined'
                      ? 'bg-[#2b4635] text-[#faf5e9] border-[#2b4635] shadow-sm font-semibold'
                      : 'bg-transparent text-[#2b4635] border-[rgba(43,70,53,0.2)] hover:border-[#2b4635]'
                  }`}
                >
                  REGRETFULLY DECLINE
                </button>
              </div>
            </div>

            {/* Side Selection */}
            <div>
              <label className="font-cinzel text-[9px] tracking-[0.22em] text-[#2b4635] block mb-2 font-semibold">
                <span className="inline-block w-4 h-4 rounded-full bg-[#2b4635] text-[#faf5e9] text-center leading-4 text-[8.5px] mr-1.5">
                  2
                </span>
                GUEST OF
              </label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setSide('groom')}
                  className={`py-2.5 px-3 rounded-md border font-cinzel text-[9px] tracking-[0.18em] transition-all cursor-pointer ${
                    side === 'groom'
                      ? 'bg-[#faf5e9] text-[#2b4635] border-[#a07820] font-semibold ring-1 ring-[#a07820]'
                      : 'bg-transparent text-[#5b6840] border-[rgba(160,120,32,0.22)]'
                  }`}
                >
                  GROOM'S FAMILY
                </button>
                <button
                  type="button"
                  onClick={() => setSide('bride')}
                  className={`py-2.5 px-3 rounded-md border font-cinzel text-[9px] tracking-[0.18em] transition-all cursor-pointer ${
                    side === 'bride'
                      ? 'bg-[#faf5e9] text-[#2b4635] border-[#a07820] font-semibold ring-1 ring-[#a07820]'
                      : 'bg-transparent text-[#5b6840] border-[rgba(160,120,32,0.22)]'
                  }`}
                >
                  BRIDE'S FAMILY
                </button>
              </div>
            </div>

            {/* Guest Name & WhatsApp */}
            <div className="space-y-4">
              <div>
                <label className="font-cinzel text-[9px] tracking-[0.22em] text-[#2b4635] block mb-1.5 font-semibold">
                  <span className="inline-block w-4 h-4 rounded-full bg-[#2b4635] text-[#faf5e9] text-center leading-4 text-[8.5px] mr-1.5">
                    3
                  </span>
                  YOUR FULL NAME *
                </label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Robin Mathew"
                  className="w-full px-4 py-2.5 rounded-md bg-[#faf5e9]/50 border border-[rgba(160,120,32,0.25)] font-cormorant text-[17.5px] text-[#2b4635] placeholder:text-[#5b6840]/50 focus:outline-none focus:border-[#a07820] focus:bg-white"
                  required
                />
              </div>

              <div>
                <label className="font-cinzel text-[9px] tracking-[0.22em] text-[#2b4635] block mb-1.5 font-semibold">
                  <span className="inline-block w-4 h-4 rounded-full bg-[#2b4635] text-[#faf5e9] text-center leading-4 text-[8.5px] mr-1.5">
                    4
                  </span>
                  WHATSAPP CONTACT *
                </label>
                <input
                  type="tel"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="+91 98765 43210"
                  className="w-full px-4 py-2.5 rounded-md bg-[#faf5e9]/50 border border-[rgba(160,120,32,0.25)] font-cormorant text-[17.5px] text-[#2b4635] placeholder:text-[#5b6840]/50 focus:outline-none focus:border-[#a07820] focus:bg-white"
                  required
                />
              </div>
            </div>

            {/* If Attending: Guest Count & Events */}
            {attendingStatus === 'attending' && (
              <>
                <div>
                  <label className="font-cinzel text-[9px] tracking-[0.22em] text-[#2b4635] block mb-2 font-semibold">
                    <span className="inline-block w-4 h-4 rounded-full bg-[#2b4635] text-[#faf5e9] text-center leading-4 text-[8.5px] mr-1.5">
                      5
                    </span>
                    NUMBER OF GUESTS: <strong className="font-serif text-[#2b4635] text-[16px] ml-1">{guestCount}</strong>
                  </label>
                  <div className="flex gap-2">
                    {[1, 2, 3, 4, 5].map((num) => (
                      <button
                        key={num}
                        type="button"
                        onClick={() => setGuestCount(num)}
                        className={`flex-1 py-2 rounded-md border font-cinzel text-[11px] font-semibold transition-all cursor-pointer ${
                          guestCount === num
                            ? 'bg-[#2b4635] text-[#faf5e9] border-[#2b4635] shadow-sm'
                            : 'bg-[#faf5e9]/50 text-[#2b4635] border-[rgba(160,120,32,0.22)] hover:border-[#a07820]'
                        }`}
                      >
                        {num}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="space-y-2 pt-1 font-cormorant text-[16.5px] text-[#2b4635]">
                  <label className="flex items-center gap-3 p-3 rounded-md border border-[rgba(160,120,32,0.2)] bg-[#faf5e9]/40 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={attendingCeremony}
                      onChange={(e) => setAttendingCeremony(e.target.checked)}
                      className="accent-[#2b4635] w-4 h-4"
                    />
                    <div className="leading-tight">
                      <span className="font-semibold block">Holy Wedding Ceremony &bull; 11:30 AM</span>
                      <span className="text-[14px] text-[#5b6840] italic">Stay Samara, Kottayam</span>
                    </div>
                  </label>

                  <label className="flex items-center gap-3 p-3 rounded-md border border-[rgba(160,120,32,0.2)] bg-[#faf5e9]/40 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={attendingReception}
                      onChange={(e) => setAttendingReception(e.target.checked)}
                      className="accent-[#2b4635] w-4 h-4"
                    />
                    <div className="leading-tight">
                      <span className="font-semibold block">Wedding Feast &amp; Reception</span>
                      <span className="text-[14px] text-[#5b6840] italic">Following the holy service</span>
                    </div>
                  </label>
                </div>
              </>
            )}

            {/* Note */}
            <div>
              <label className="font-cinzel text-[9px] tracking-[0.22em] text-[#2b4635] block mb-1.5 font-semibold">
                PERSONAL NOTE (OPTIONAL)
              </label>
              <textarea
                value={note}
                onChange={(e) => setNote(e.target.value)}
                placeholder="Share a sweet note or blessing with the couple..."
                rows={2}
                className="w-full px-4 py-2.5 rounded-md bg-[#faf5e9]/50 border border-[rgba(160,120,32,0.25)] font-cormorant text-[17px] text-[#2b4635] placeholder:text-[#5b6840]/50 focus:outline-none focus:border-[#a07820] focus:bg-white resize-none"
              />
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-4 bg-[#2b4635] hover:bg-[#3a5c46] disabled:opacity-60 text-[#faf5e9] font-cinzel text-[10.5px] tracking-[0.28em] font-semibold rounded-md shadow-md transition-all cursor-pointer flex items-center justify-center gap-2"
            >
              <Send className="w-3.5 h-3.5 text-[#a07820]" />
              <span>{isSubmitting ? 'SENDING RESPONSE...' : 'CONFIRM RSVP ✦'}</span>
            </button>
          </form>
        )}

        {/* Admin option to view RSVPs directly at bottom of RSVP section */}
        <div className="mt-8 pt-4 flex justify-center">
          <AdminPortal triggerType="rsvp-link" />
        </div>
      </div>
    </section>
  );
};
