import React from 'react';
import { WEDDING_DETAILS } from '../data/weddingData';

interface HeroSectionProps {
  onScrollToDetails: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({ onScrollToDetails }) => {
  return (
    <section className="relative w-full pt-24 sm:pt-32 pb-16 px-6 sm:px-10 text-center border-b border-[#a07820]/25 overflow-hidden">
      {/* Background Image: IMG_2023 with airy top headroom and soft luxury scrim */}
      <div className="absolute inset-0 z-0 pointer-events-none overflow-hidden">
        <img
          src="/assets/aistudio/IMG_2023_0404ac9a.PNG"
          alt="Blesson & Glinta"
          className="w-full h-full object-cover object-[50%_45%] opacity-45 scale-105 transition-transform duration-1000"
        />
        {/* Soft luxury scrim overlay so text breathes with royal elegance */}
        <div className="absolute inset-0 bg-gradient-to-b from-[#f2ebda]/95 via-[#f2ebda]/70 to-[#f2ebda]/95" />
      </div>

      <div className="relative z-10 max-w-md mx-auto flex flex-col items-center">
        {/* Transparent Monogram Letter Logo matching uploaded screenshot */}
        <div className="mb-6 flex justify-center">
          <svg width="76" height="76" viewBox="0 0 100 100" className="mx-auto text-[#a07820] transition-transform duration-500 hover:scale-105">
            <circle cx="50" cy="50" r="46" fill="none" stroke="currentColor" strokeWidth="1.2" strokeDasharray="3 3" />
            <circle cx="50" cy="50" r="41" fill="none" stroke="currentColor" strokeWidth="0.8" />
            <text x="50" y="55" textAnchor="middle" fontFamily="'Italiana', serif" fontSize="24" fill="#2b4635">
              B &amp; G
            </text>
            <text x="50" y="73" textAnchor="middle" fontFamily="'Cinzel', serif" fontSize="6.5" letterSpacing="0.25em" fill="#a07820">
              DEC 2026
            </text>
          </svg>
        </div>

        {/* Scripture Verse Line */}
        <div className="font-cormorant italic text-[16.5px] sm:text-[19px] text-[#6d1d2c] leading-relaxed mb-5 max-w-[34ch]">
          &ldquo;This was the Lord’s doing; it is marvelous in our eyes.&rdquo;
          <br />
          <span className="font-cinzel not-italic text-[9px] tracking-[0.32em] opacity-80 text-[#2b4635] block mt-1.5 font-semibold">
            PSALM 118 : 23
          </span>
        </div>

        {/* Section Eyebrow */}
        <span className="font-cinzel tracking-[0.44em] text-[9.5px] text-[#7d2233] block mb-5 uppercase font-semibold">
          — WEDDING INVITATION —
        </span>

        {/* Monumental Couple Names in Italiana font with Playfair ampersand */}
        <h2 className="font-italiana text-[54px] sm:text-[76px] leading-[0.9] text-[#2b4635] mb-6 drop-shadow-sm">
          Blesson
          <span className="font-playfair italic text-[#7d2233] inline-block text-[0.52em] align-middle mx-2.5">
            &amp;
          </span>
          Glinta
        </h2>

        {/* Invitation Message */}
        <div className="max-w-[42ch] mx-auto text-[#2b4635] font-cormorant font-semibold text-[18.5px] sm:text-[20px] leading-[1.85] italic mb-6">
          <p>
            Together with our families, we warmly invite you to join us in blessing our Holy Matrimony and the beginning of our life together.
          </p>
        </div>

        {/* Divider with spring-green center dot */}
        <div className="divider">
          <span />
          <div className="dot" />
          <span />
        </div>
      </div>
    </section>
  );
};
