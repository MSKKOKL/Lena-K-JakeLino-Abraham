import React, { useState, useEffect } from 'react';
import { Volume2, VolumeX, Music } from 'lucide-react';
import { weddingAudio } from '../utils/audioPlayer';

export const MusicController: React.FC = () => {
  const [isPlaying, setIsPlaying] = useState(false);

  useEffect(() => {
    const checkAudio = () => {
      setIsPlaying(weddingAudio.isAudioPlaying());
    };
    const interval = setInterval(checkAudio, 800);
    return () => clearInterval(interval);
  }, []);

  const handleTogglePlay = () => {
    const state = weddingAudio.toggle();
    setIsPlaying(state);
  };

  return (
    <div className="fixed bottom-6 right-5 z-[80]">
      <button
        onClick={handleTogglePlay}
        type="button"
        id="bgmBtn"
        aria-label={isPlaying ? 'Pause music' : 'Play music'}
        title={isPlaying ? 'Pause music' : 'Play music'}
        className="relative w-12 h-12 rounded-full bg-[rgba(253,249,240,0.95)] border border-[rgba(160,120,32,0.45)] shadow-lg backdrop-blur-md flex items-center justify-center cursor-pointer transition-transform hover:scale-105 active:scale-95"
      >
        {/* Animated Dashed Ring when playing */}
        {isPlaying && (
          <div className="absolute -inset-1 rounded-full border-2 border-dashed border-[rgba(160,120,32,0.6)] animate-spin-slow pointer-events-none" />
        )}

        {/* Music / Speaker Icon */}
        {isPlaying ? (
          <Volume2 className="w-5 h-5 text-[#2b4635]" />
        ) : (
          <VolumeX className="w-5 h-5 text-[#5b6840]" />
        )}
      </button>
    </div>
  );
};
