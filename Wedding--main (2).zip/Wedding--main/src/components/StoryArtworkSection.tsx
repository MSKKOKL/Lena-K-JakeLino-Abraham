import React, { useState, useEffect, useRef } from 'react';
import { STORY_ARTWORK, WEDDING_DETAILS } from '../data/weddingData';

export const StoryArtworkSection: React.FC = () => {
  const fullQuote = "From little hello’s to endless talks what started as a simple connection, slowly became our forever affection.";
  const [displayedText, setDisplayedText] = useState('');
  const [isTyping, setIsTyping] = useState(true);
  const cardRef = useRef<HTMLDivElement>(null);
  const [hasStarted, setHasStarted] = useState(false);

  // Trigger typewriter effect when the story card scrolls into view
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting && !hasStarted) {
          setHasStarted(true);
        }
      },
      { threshold: 0.25 }
    );
    if (cardRef.current) observer.observe(cardRef.current);
    return () => observer.disconnect();
  }, [hasStarted]);

  useEffect(() => {
    if (!hasStarted) return;
    let index = 0;
    setDisplayedText('');
    setIsTyping(true);

    const interval = setInterval(() => {
      index++;
      setDisplayedText(fullQuote.slice(0, index));
      if (index >= fullQuote.length) {
        clearInterval(interval);
        setIsTyping(false);
      }
    }, 42);

    return () => clearInterval(interval);
  }, [hasStarted, fullQuote]);

  return (
    <section className="relative w-full py-16 px-6 sm:px-10 text-center border-b border-[#a07820]/25 bg-transparent overflow-hidden">
      <div className="max-w-md mx-auto flex flex-col items-center">
        {/* Eyebrow */}
        <div className="section-eyebrow">— THE COUPLE —</div>

        {/* Monumental Names */}
        <h2 className="font-italiana text-[50px] sm:text-[68px] leading-[0.9] text-[#2b4635] mb-10">
          Blesson{' '}
          <span className="font-playfair italic text-[#7d2233] text-[0.52em] align-middle">
            &amp;
          </span>{' '}
          Glinta
        </h2>

        {/* BRIDE */}
        <div className="mb-8 w-full">
          <div className="font-cinzel tracking-[0.42em] text-[9.5px] text-[#6d1d2c] mb-3 uppercase">
            B R I D E
          </div>
          <div className="font-italiana text-[32px] sm:text-[42px] text-[#2b4635] leading-tight mb-2">
            {WEDDING_DETAILS.bride.fullName}
          </div>
          <div className="font-cormorant italic text-[19px] sm:text-[20px] text-[#5b6840] leading-relaxed">
            <span>D/o {WEDDING_DETAILS.bride.fatherName} &amp; {WEDDING_DETAILS.bride.motherName}</span>
            <br />
            <span>Kottayam, Kerala</span>
          </div>
        </div>

        {/* Delicate Center Dot Divider */}
        <div className="flex items-center justify-center gap-3.5 my-4 w-44 mx-auto">
          <span className="flex-1 h-[1px] bg-[#a07820]/30" />
          <span className="w-1.5 h-1.5 rounded-full bg-[#a07820] shrink-0" />
          <span className="flex-1 h-[1px] bg-[#a07820]/30" />
        </div>

        {/* GROOM */}
        <div className="mb-10 w-full">
          <div className="font-cinzel tracking-[0.42em] text-[9.5px] text-[#6d1d2c] mb-3 uppercase">
            G R O O M
          </div>
          <div className="font-italiana text-[32px] sm:text-[42px] text-[#2b4635] leading-tight mb-2">
            {WEDDING_DETAILS.groom.fullName}
          </div>
          <div className="font-cormorant italic text-[19px] sm:text-[20px] text-[#5b6840] leading-relaxed">
            <span>S/o {WEDDING_DETAILS.groom.fatherName} &amp; {WEDDING_DETAILS.groom.motherName}</span>
            <br />
            <span>Kottayam, Kerala</span>
          </div>
        </div>

        {/* Love Story Artwork Card: Malta to Canada */}
        <div className="w-full mt-4 mb-2">
          <div className="font-cinzel tracking-[0.35em] text-[9px] text-[#6d1d2c] mb-3 uppercase font-semibold">
            OUR STORY · MALTA TO CANADA
          </div>

          <div
            ref={cardRef}
            className="relative rounded-2xl overflow-hidden bg-[#fffdf7] border border-[#a07820]/35 shadow-[0_6px_24px_rgba(43,70,53,0.08)] p-2"
          >
            <div className="relative rounded-xl overflow-hidden">
              <img
                src={STORY_ARTWORK.url}
                alt="Blesson & Glinta - Malta to Canada Story"
                className="w-full h-auto object-cover"
                loading="lazy"
              />

              {/* Automatic Professional Typewriter Quote positioned right in the middle of the image */}
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[92%] sm:w-[86%] z-10 pointer-events-none">
                <div className="px-3.5 py-3 sm:px-4 sm:py-3.5 rounded-xl bg-[#faf5e9]/92 backdrop-blur-md border border-[#a07820]/45 shadow-[0_8px_24px_rgba(43,70,53,0.2)] text-center">
                  <div className="flex items-center justify-center gap-2 mb-1 opacity-70">
                    <span className="w-5 h-[1px] bg-[#a07820]" />
                    <span className="text-[#a07820] text-xs">❦</span>
                    <span className="w-5 h-[1px] bg-[#a07820]" />
                  </div>
                  <p className="font-cormorant italic font-semibold text-[15.5px] sm:text-[18px] text-[#2b4635] leading-snug">
                    &ldquo;{displayedText}&rdquo;
                    {isTyping && (
                      <span className="inline-block w-[2px] h-[0.9em] bg-[#a07820] ml-1 align-middle animate-pulse" />
                    )}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Divider */}
        <div className="divider">
          <span />
          <div className="dot" />
          <span />
        </div>
      </div>

    </section>
  );
};
