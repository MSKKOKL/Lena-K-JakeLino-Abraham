import React, { useState } from 'react';
import { Calendar, Clock, MapPin, Navigation, Share2, Check, ExternalLink } from 'lucide-react';
import { WEDDING_DETAILS } from '../data/weddingData';
import { generateGoogleCalendarUrl } from '../utils/countdown';

export const EventDetailsSection: React.FC = () => {
  const [copied, setCopied] = useState(false);

  const googleCalUrl = generateGoogleCalendarUrl({
    title: `Holy Wedding · Blesson & Glinta`,
    details: `Holy Wedding from 11:30 AM at Stay Samara, Kottayam.`,
    location: `${WEDDING_DETAILS.venueName}, ${WEDDING_DETAILS.venueLocation}`,
    startDate: '2026-12-07T06:00:00.000Z',
    endDate: '2026-12-07T10:30:00.000Z',
  });

  const mapsUrl = `https://www.google.com/maps/search/?api=1&query=${WEDDING_DETAILS.mapQuery}`;

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'Wedding of Blesson & Glinta',
          text: `You're lovingly invited to the Holy Wedding of Blesson Abraham & Glinta Jofna on 7 December 2026 at Stay Samara, Kottayam.`,
          url: window.location.href,
        });
      } catch {
        // cancelled
      }
    } else {
      navigator.clipboard.writeText(window.location.href);
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    }
  };

  return (
    <section id="event-details" className="relative w-full py-16 px-6 sm:px-10 text-center border-b border-[#a07820]/25 bg-transparent">
      <div className="max-w-md mx-auto flex flex-col items-center">
        {/* Eyebrow */}
        <div className="section-eyebrow">— THE OCCASION —</div>

        {/* Section Title */}
        <h2 className="section-title">The Wedding Day</h2>

        {/* Event Card matching Sara weds Isaac .event-card */}
        <div className="w-full bg-[#fffdf7] border border-[#a07820]/30 rounded-xl p-6 shadow-[0_4px_18px_rgba(43,70,53,0.06)] text-left space-y-4">
          {/* Card Header */}
          <div className="flex items-center gap-3 pb-3 border-b border-[#a07820]/20">
            <span className="font-cinzel text-base text-[#a07820] font-bold">01</span>
            <span className="font-cinzel text-xs tracking-[0.24em] text-[#2b4635] font-semibold uppercase">
              HOLY WEDDING &amp; RECEPTION
            </span>
          </div>

          {/* Date & Time Row */}
          <div className="flex items-start gap-3 py-1">
            <div className="w-8 h-8 rounded-lg bg-[#2b4635]/10 text-[#2b4635] flex items-center justify-center shrink-0">
              <Clock className="w-4 h-4" />
            </div>
            <div>
              <span className="font-cinzel text-[8px] tracking-[0.22em] text-[#5b6840] uppercase block">
                DATE &amp; TIME
              </span>
              <p className="font-cormorant text-lg text-[#2b4635] font-semibold leading-tight mt-0.5">
                {WEDDING_DETAILS.dateStr}
              </p>
              <p className="font-cormorant italic text-sm text-[#7d2233] mt-0.5">
                Holy Wedding from {WEDDING_DETAILS.holyWeddingTime}
              </p>
            </div>
          </div>

          {/* Venue Row */}
          <div className="flex items-start gap-3 py-1">
            <div className="w-8 h-8 rounded-lg bg-[#a07820]/15 text-[#a07820] flex items-center justify-center shrink-0">
              <MapPin className="w-4 h-4" />
            </div>
            <div>
              <span className="font-cinzel text-[8px] tracking-[0.22em] text-[#5b6840] uppercase block">
                VENUE
              </span>
              <p className="font-cormorant text-lg text-[#2b4635] font-semibold leading-tight mt-0.5">
                {WEDDING_DETAILS.venueName}
              </p>
              <p className="font-cormorant text-sm text-[#5b6840] mt-0.5">
                {WEDDING_DETAILS.venueLocation}
              </p>
            </div>
          </div>

          {/* Action Buttons: Directions, Calendar, Share */}
          <div className="flex flex-wrap items-center gap-2 pt-3 border-t border-[#a07820]/15">
            <a
              href={mapsUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded bg-[#2b4635] hover:bg-[#3a5c46] text-[#faf5e9] font-cinzel text-[9px] tracking-[0.2em] uppercase transition-all shadow-sm cursor-pointer"
            >
              <Navigation className="w-3.5 h-3.5" />
              <span>DIRECTIONS</span>
              <ExternalLink className="w-3 h-3 opacity-70" />
            </a>

            <a
              href={googleCalUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded border border-[#a07820]/50 hover:bg-[#a07820]/10 text-[#2b4635] font-cinzel text-[9px] tracking-[0.2em] uppercase transition-all shadow-sm cursor-pointer"
            >
              <Calendar className="w-3.5 h-3.5 text-[#a07820]" />
              <span>CALENDAR</span>
            </a>

            <button
              onClick={handleShare}
              type="button"
              className="inline-flex items-center gap-1.5 px-3 py-2.5 rounded border border-[#a07820]/30 hover:border-[#a07820] text-[#2b4635] font-cinzel text-[9px] tracking-[0.2em] uppercase transition-all cursor-pointer ml-auto"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Share2 className="w-3.5 h-3.5" />}
              <span>{copied ? 'COPIED' : 'SHARE'}</span>
            </button>
          </div>
        </div>

        {/* Divider */}
        <div className="divider">
          <span />
          <div className="dot" />
          <span />
        </div>
      </div>
    </section>
  );
};
