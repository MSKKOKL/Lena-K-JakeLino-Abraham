import React, { useState, useEffect, useRef } from 'react';
import { ChevronLeft, ChevronRight, Heart } from 'lucide-react';
import { GALLERY_PHOTOS } from '../data/weddingData';

export const GallerySection: React.FC = () => {
  const [activeIdx, setActiveIdx] = useState(0);
  const [isPaused, setIsPaused] = useState(false);
  const [likedMap, setLikedMap] = useState<Record<string, boolean>>({});
  const touchStartXRef = useRef<number | null>(null);
  const touchEndXRef = useRef<number | null>(null);

  const total = GALLERY_PHOTOS.length;

  useEffect(() => {
    if (isPaused) return;
    const interval = setInterval(() => {
      setActiveIdx((prev) => (prev + 1) % total);
    }, 3500);
    return () => clearInterval(interval);
  }, [isPaused, total]);

  const handlePrev = (e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    setActiveIdx((prev) => (prev - 1 + total) % total);
  };

  const handleNext = (e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    setActiveIdx((prev) => (prev + 1) % total);
  };

  const handleTouchStart = (e: React.TouchEvent) => {
    setIsPaused(true);
    touchStartXRef.current = e.targetTouches[0].clientX;
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    touchEndXRef.current = e.targetTouches[0].clientX;
  };

  const handleTouchEnd = () => {
    if (touchStartXRef.current !== null && touchEndXRef.current !== null) {
      const diffX = touchStartXRef.current - touchEndXRef.current;
      if (diffX > 40) {
        handleNext();
      } else if (diffX < -40) {
        handlePrev();
      }
    }
    touchStartXRef.current = null;
    touchEndXRef.current = null;
    setTimeout(() => setIsPaused(false), 2500);
  };

  const toggleLike = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    setLikedMap((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  const prevIdx = (activeIdx - 1 + total) % total;
  const nextIdx = (activeIdx + 1) % total;

  return (
    <section
      className="relative w-full py-16 px-6 sm:px-10 text-center border-b border-[#a07820]/25 bg-transparent overflow-hidden select-none"
      onMouseEnter={() => setIsPaused(true)}
      onMouseLeave={() => setIsPaused(false)}
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
    >
      <div className="max-w-md mx-auto flex flex-col items-center">
        {/* Eyebrow */}
        <div className="section-eyebrow">— A LITTLE GLIMPSE OF OUR STORY —</div>

        {/* Title */}
        <h2 className="section-title text-[32px] sm:text-[44px]">A Little Glimpse of Our Story</h2>

        {/* Carousel Viewport with Center Card and Side Peeking Cards */}
        <div className="relative w-full h-[400px] sm:h-[450px] flex items-center justify-center overflow-visible mb-6">
          {/* Left Peeking Card */}
          <div
            onClick={handlePrev}
            className="absolute left-[-10%] sm:left-[-6%] w-[58%] sm:w-[52%] aspect-[3/4] rounded-[20px] overflow-hidden opacity-45 scale-[0.88] blur-[0.4px] cursor-pointer transition-all duration-700 ease-out z-0 hover:opacity-70 shadow-md border border-[#a07820]/30 bg-[#fffdf7]"
          >
            <img
              src={GALLERY_PHOTOS[prevIdx].url}
              alt={GALLERY_PHOTOS[prevIdx].title}
              className="w-full h-full object-cover object-center pointer-events-none"
              loading="lazy"
            />
          </div>

          {/* Center Active Card */}
          <div className="relative w-[76%] sm:w-[68%] aspect-[3/4] rounded-[22px] overflow-hidden border-[4px] border-[#fffdf7] shadow-[0_16px_40px_rgba(43,70,53,0.15)] z-10 transition-all duration-700 ease-out bg-[#fffdf7] group">
            <img
              src={GALLERY_PHOTOS[activeIdx].url}
              alt={GALLERY_PHOTOS[activeIdx].title}
              className="w-full h-full object-cover object-center pointer-events-none transition-transform duration-700"
              loading="eager"
            />

            {/* Photo title tag */}
            <div className="absolute bottom-0 inset-x-0 bg-gradient-to-t from-[#2b4635]/80 via-transparent to-transparent pt-10 pb-3 px-4 text-center pointer-events-none">
              <span className="font-cinzel text-[9px] uppercase tracking-[0.22em] text-[#faf5e9] font-medium">
                {GALLERY_PHOTOS[activeIdx].title}
              </span>
            </div>

            {/* Heart button */}
            <button
              onClick={(e) => toggleLike(e, GALLERY_PHOTOS[activeIdx].id)}
              aria-label="Like photo"
              className="absolute top-3 right-3 p-2 rounded-full bg-black/40 hover:bg-black/60 text-white backdrop-blur-sm cursor-pointer transition-transform active:scale-90"
            >
              <Heart
                className={`w-3.5 h-3.5 ${
                  likedMap[GALLERY_PHOTOS[activeIdx].id] ? 'fill-[#7d2233] text-[#7d2233]' : 'text-white'
                }`}
              />
            </button>
          </div>

          {/* Right Peeking Card */}
          <div
            onClick={handleNext}
            className="absolute right-[-10%] sm:right-[-6%] w-[58%] sm:w-[52%] aspect-[3/4] rounded-[20px] overflow-hidden opacity-45 scale-[0.88] blur-[0.4px] cursor-pointer transition-all duration-700 ease-out z-0 hover:opacity-70 shadow-md border border-[#a07820]/30 bg-[#fffdf7]"
          >
            <img
              src={GALLERY_PHOTOS[nextIdx].url}
              alt={GALLERY_PHOTOS[nextIdx].title}
              className="w-full h-full object-cover object-center pointer-events-none"
              loading="lazy"
            />
          </div>
        </div>

        {/* Carousel Controls: Arrows + Dots */}
        <div className="flex items-center justify-center gap-4 py-2">
          <button
            onClick={handlePrev}
            type="button"
            aria-label="Previous"
            className="w-8 h-8 rounded-full border border-[#a07820]/40 hover:border-[#a07820] flex items-center justify-center text-[#2b4635] bg-[#fffdf7] cursor-pointer transition-transform active:scale-90 shadow-sm"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>

          <div className="flex items-center gap-2">
            {GALLERY_PHOTOS.map((_, idx) => (
              <button
                key={idx}
                onClick={() => setActiveIdx(idx)}
                aria-label={`Go to photo ${idx + 1}`}
                className={`rounded-full transition-all duration-500 cursor-pointer ${
                  activeIdx === idx
                    ? 'w-2.5 h-2.5 bg-[#a07820] scale-110 shadow-sm'
                    : 'w-2 h-2 bg-[#a07820]/30 hover:bg-[#a07820]/60'
                }`}
              />
            ))}
          </div>

          <button
            onClick={handleNext}
            type="button"
            aria-label="Next"
            className="w-8 h-8 rounded-full border border-[#a07820]/40 hover:border-[#a07820] flex items-center justify-center text-[#2b4635] bg-[#fffdf7] cursor-pointer transition-transform active:scale-90 shadow-sm"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        {/* Divider */}
        <div className="divider">
          <span />
          <div className="dot" />
          <span />
        </div>
      </div>
    </section>
  );
};
