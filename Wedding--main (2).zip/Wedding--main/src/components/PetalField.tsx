import React from 'react';

const PETAL_CONFIGS = [
  { left: '2%', dur: '17s', delay: '0s', w: '15px', sway: '4.5s', tone: 't-light' },
  { left: '10%', dur: '21s', delay: '-3s', w: '12px', sway: '5.5s', tone: 't-mid' },
  { left: '20%', dur: '25s', delay: '-7s', w: '18px', sway: '6s', tone: 't-deep' },
  { left: '32%', dur: '19s', delay: '-12s', w: '13px', sway: '4s', tone: 't-light' },
  { left: '45%', dur: '23s', delay: '-2s', w: '16px', sway: '5s', tone: 't-mid' },
  { left: '58%', dur: '27s', delay: '-15s', w: '11px', sway: '6.5s', tone: 't-deep' },
  { left: '68%', dur: '20s', delay: '-9s', w: '15px', sway: '4.8s', tone: 't-light' },
  { left: '78%', dur: '22s', delay: '-5s', w: '19px', sway: '5.2s', tone: 't-mid' },
  { left: '88%', dur: '18s', delay: '-18s', w: '12px', sway: '6s', tone: 't-deep' },
  { left: '95%', dur: '24s', delay: '-11s', w: '15px', sway: '4.6s', tone: 't-light' },
  { left: '15%', dur: '29s', delay: '-20s', w: '10px', sway: '7s', tone: 't-mid' },
  { left: '50%', dur: '16s', delay: '-6s', w: '14px', sway: '4.2s', tone: 't-deep' },
  { left: '72%', dur: '26s', delay: '-14s', w: '17px', sway: '5.8s', tone: 't-light' },
  { left: '38%', dur: '21s', delay: '-8s', w: '12px', sway: '5s', tone: 't-mid' },
];

export const PetalField: React.FC = () => {
  return (
    <div className="petal-field" aria-hidden="true">
      {PETAL_CONFIGS.map((c, i) => (
        <div
          key={i}
          className="petal-wrap"
          style={{
            left: c.left,
            animationDuration: c.dur,
            animationDelay: c.delay,
          }}
        >
          <div
            className={`petal ${c.tone}`}
            style={{
              width: c.w,
              height: `calc(${c.w} * 1.18)`,
              animationDelay: c.delay,
              animationDuration: c.sway,
            }}
          />
        </div>
      ))}
    </div>
  );
};
