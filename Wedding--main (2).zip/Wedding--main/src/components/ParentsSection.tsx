import React from 'react';
import { WEDDING_DETAILS } from '../data/weddingData';

export const ParentsSection: React.FC = () => {
  return (
    <section className="families py-16 px-5 sm:px-8 text-center relative overflow-hidden border-b border-[rgba(160,120,32,0.25)]">
      <div className="max-w-xl mx-auto">
        <div className="section-eyebrow">— TOGETHER WITH THEIR FAMILIES —</div>
        <h2 className="section-title">Meet Our Families</h2>

        <div className="divider">
          <span />
          <div className="dot" />
          <span />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 text-left mt-8">
          {/* Groom's Family Card */}
          <div className="sara-card p-6 sm:p-7 relative transition-all duration-300 hover:shadow-lg">
            <div className="flex items-center gap-4 mb-4 pb-4 border-b border-dashed border-[#2b4635]/20">
              <div className="shrink-0 p-[2.5px] rounded-full bg-gradient-to-tr from-[#2b4635] via-[#a07820] to-[#3a5c46]">
                <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-full bg-[#faf5e9] flex items-center justify-center font-italiana text-2xl text-[#a07820] border-2 border-white shadow-inner">
                  B
                </div>
              </div>
              <div>
                <h3 className="font-cormorant font-semibold italic text-2xl text-[#2b4635] leading-tight">
                  {WEDDING_DETAILS.groom.fullName}
                </h3>
                <p className="font-cinzel text-[8.5px] tracking-[0.28em] text-[#5b6840] uppercase mt-1">
                  The Groom &bull; Kottayam
                </p>
              </div>
            </div>

            <div className="text-[16px] text-[#5b6840] font-cormorant italic leading-relaxed space-y-3">
              <div>
                <strong className="block font-cinzel not-italic text-[8px] tracking-[0.25em] text-[#2b4635] uppercase mb-1">
                  Parents
                </strong>
                <p className="font-semibold text-[#2b4635]">
                  {WEDDING_DETAILS.groom.fatherName} &amp; {WEDDING_DETAILS.groom.motherName}
                </p>
              </div>

              <div className="pt-2 border-t border-[rgba(160,120,32,0.15)]">
                <strong className="block font-cinzel not-italic text-[8px] tracking-[0.25em] text-[#2b4635] uppercase mb-1">
                  Residence
                </strong>
                <p className="text-[#5b6840]">
                  Kottayam, Kerala
                </p>
              </div>
            </div>
          </div>

          {/* Bride's Family Card */}
          <div className="sara-card p-6 sm:p-7 relative transition-all duration-300 hover:shadow-lg">
            <div className="flex items-center gap-4 mb-4 pb-4 border-b border-dashed border-[#2b4635]/20">
              <div className="shrink-0 p-[2.5px] rounded-full bg-gradient-to-tr from-[#7d2233] via-[#a07820] to-[#2b4635]">
                <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-full bg-[#faf5e9] flex items-center justify-center font-italiana text-2xl text-[#7d2233] border-2 border-white shadow-inner">
                  G
                </div>
              </div>
              <div>
                <h3 className="font-cormorant font-semibold italic text-2xl text-[#2b4635] leading-tight">
                  {WEDDING_DETAILS.bride.fullName}
                </h3>
                <p className="font-cinzel text-[8.5px] tracking-[0.28em] text-[#5b6840] uppercase mt-1">
                  The Bride &bull; Kottayam
                </p>
              </div>
            </div>

            <div className="text-[16px] text-[#5b6840] font-cormorant italic leading-relaxed space-y-3">
              <div>
                <strong className="block font-cinzel not-italic text-[8px] tracking-[0.25em] text-[#2b4635] uppercase mb-1">
                  Parents
                </strong>
                <p className="font-semibold text-[#2b4635]">
                  {WEDDING_DETAILS.bride.fatherName} &amp; {WEDDING_DETAILS.bride.motherName}
                </p>
              </div>

              <div className="pt-2 border-t border-[rgba(160,120,32,0.15)]">
                <strong className="block font-cinzel not-italic text-[8px] tracking-[0.25em] text-[#2b4635] uppercase mb-1">
                  Residence
                </strong>
                <p className="text-[#5b6840]">
                  Kottayam, Kerala
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
