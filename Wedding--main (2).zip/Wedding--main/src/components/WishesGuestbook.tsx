import React, { useState, useEffect } from 'react';
import { Heart, Send, Sparkles } from 'lucide-react';
import confetti from 'canvas-confetti';
import { collection, doc, setDoc, updateDoc, onSnapshot } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import { INITIAL_WISHES } from '../data/weddingData';
import { WishEntry } from '../types';

export const WishesGuestbook: React.FC = () => {
  const [wishes, setWishes] = useState<WishEntry[]>(() => {
    try {
      const saved = localStorage.getItem('blesson_glinta_wishes');
      if (saved) {
        const parsed: WishEntry[] = JSON.parse(saved);
        return parsed.filter(
          (w) => w.id !== 'wish-1' && w.id !== 'wish-2' && w.id !== 'wish-3'
        );
      }
      return INITIAL_WISHES;
    } catch {
      return INITIAL_WISHES;
    }
  });

  const [author, setAuthor] = useState('');
  const [relation, setRelation] = useState("Well-wisher");
  const [message, setMessage] = useState('');
  const [likedMap, setLikedMap] = useState<Record<string, boolean>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [visibleCount, setVisibleCount] = useState(4);

  // Real-time listener for wishes collection from Firestore
  useEffect(() => {
    const unsub = onSnapshot(
      collection(db, 'wishes'),
      (snapshot) => {
        const list: WishEntry[] = snapshot.docs.map((docSnap) => {
          const data = docSnap.data();
          return {
            id: docSnap.id,
            author: data.authorName || 'Guest',
            relation: data.relationship || 'Well-wisher',
            message: data.message || '',
            likes: Number(data.likes) || 1,
            createdAt: data.createdAt ? new Date(data.createdAt).toLocaleDateString() : 'Recent',
          };
        });

        const cleaned = list.filter((w) => w.id !== 'wish-1' && w.id !== 'wish-2' && w.id !== 'wish-3');
        if (cleaned.length > 0) {
          setWishes(cleaned);
          try {
            localStorage.setItem('blesson_glinta_wishes', JSON.stringify(cleaned));
          } catch {
            // ignore
          }
        }
      },
      (err) => {
        console.warn('Firestore wishes listener error:', err);
        handleFirestoreError(err, OperationType.GET, 'wishes');
      }
    );

    return () => unsub();
  }, []);

  useEffect(() => {
    try {
      localStorage.setItem('blesson_glinta_wishes', JSON.stringify(wishes));
    } catch {
      // ignore
    }
  }, [wishes]);

  const handleSubmitWish = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!author.trim() || !message.trim()) return;

    setIsSubmitting(true);
    const docId = `wish-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
    const newWish: WishEntry = {
      id: docId,
      author: author.trim(),
      relation: relation.trim() || 'Well-wisher',
      message: message.trim(),
      likes: 1,
      createdAt: 'Just now',
    };

    setWishes([newWish, ...wishes]);
    setAuthor('');
    setMessage('');
    setIsSubmitting(false);

    try {
      await setDoc(doc(db, 'wishes', docId), {
        authorName: newWish.author,
        relationship: newWish.relation,
        message: newWish.message,
        likes: 1,
        createdAt: new Date().toISOString(),
      });
    } catch (err) {
      console.warn('Error saving wish to Firestore:', err);
      try {
        handleFirestoreError(err, OperationType.WRITE, `wishes/${docId}`);
      } catch {
        // Logged
      }
    }

    confetti({
      particleCount: 40,
      spread: 65,
      origin: { y: 0.75 },
      colors: ['#2b4635', '#a07820', '#7d2233'],
    });
  };

  const handleToggleLike = async (id: string) => {
    const isLiked = likedMap[id];
    setLikedMap((prev) => ({ ...prev, [id]: !isLiked }));
    const target = wishes.find((w) => w.id === id);
    const newLikes = target ? (isLiked ? Math.max(1, target.likes - 1) : target.likes + 1) : 1;

    setWishes((prev) =>
      prev.map((w) => {
        if (w.id === id) {
          return { ...w, likes: newLikes };
        }
        return w;
      })
    );

    try {
      await updateDoc(doc(db, 'wishes', id), {
        likes: newLikes,
      });
    } catch (err) {
      console.warn('Error updating wish likes:', err);
    }
  };

  const visibleWishes = wishes.slice(0, visibleCount);

  return (
    <section className="wishes py-16 px-5 sm:px-8 text-center relative border-b border-[rgba(160,120,32,0.25)]">
      <div className="max-w-xl mx-auto">
        <div className="section-eyebrow">— SEND YOUR LOVE —</div>
        <h2 className="section-title">Wishes Wall</h2>

        <p className="font-cormorant italic text-[18px] text-[#5b6840] font-semibold max-w-md mx-auto mb-6 leading-relaxed">
          Leave a blessing for Blesson &amp; Glinta as they step into holy matrimony.
        </p>

        <div className="divider mb-8">
          <span />
          <div className="dot" />
          <span />
        </div>

        {/* Wish Form */}
        <div className="sara-card p-6 sm:p-7 text-left max-w-lg mx-auto mb-8">
          <form onSubmit={handleSubmitWish} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="font-cinzel text-[8.5px] tracking-[0.24em] text-[#2b4635] block mb-1 font-semibold">
                  YOUR NAME *
                </label>
                <input
                  type="text"
                  value={author}
                  onChange={(e) => setAuthor(e.target.value)}
                  placeholder="e.g. Thomas &amp; Family"
                  className="w-full px-3.5 py-2.5 rounded-md bg-[#faf5e9]/50 border border-[rgba(160,120,32,0.25)] font-cormorant text-[17px] text-[#2b4635] placeholder:text-[#5b6840]/50 focus:outline-none focus:border-[#a07820] focus:bg-white"
                  required
                />
              </div>

              <div>
                <label className="font-cinzel text-[8.5px] tracking-[0.24em] text-[#2b4635] block mb-1 font-semibold">
                  RELATION
                </label>
                <select
                  value={relation}
                  onChange={(e) => setRelation(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-md bg-[#faf5e9]/50 border border-[rgba(160,120,32,0.25)] font-cormorant text-[17px] text-[#2b4635] focus:outline-none focus:border-[#a07820] focus:bg-white"
                >
                  <option value="Friend">Friend</option>
                  <option value="Groom's Family">Groom's Family</option>
                  <option value="Bride's Family">Bride's Family</option>
                  <option value="Colleague">Colleague</option>
                  <option value="Well-wisher">Well-wisher</option>
                </select>
              </div>
            </div>

            <div>
              <label className="font-cinzel text-[8.5px] tracking-[0.24em] text-[#2b4635] block mb-1 font-semibold">
                YOUR BLESSING MESSAGE *
              </label>
              <textarea
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="Write your prayers, blessings, or sweet wishes for the couple..."
                rows={2}
                className="w-full px-3.5 py-2.5 rounded-md bg-[#faf5e9]/50 border border-[rgba(160,120,32,0.25)] font-cormorant text-[17px] text-[#2b4635] placeholder:text-[#5b6840]/50 focus:outline-none focus:border-[#a07820] focus:bg-white resize-none"
                required
              />
            </div>

            <button
              type="submit"
              disabled={isSubmitting || !author.trim() || !message.trim()}
              className="w-full py-3.5 bg-[#2b4635] hover:bg-[#3a5c46] disabled:opacity-50 text-[#faf5e9] font-cinzel text-[10px] tracking-[0.25em] font-semibold rounded-md shadow-md transition-all cursor-pointer flex items-center justify-center gap-2"
            >
              <Send className="w-3.5 h-3.5 text-[#a07820]" />
              <span>SEND WISH ✦</span>
            </button>
          </form>
        </div>

        {/* Wishes List Header */}
        <div className="flex items-center justify-center gap-2 mb-5">
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#2b4635]/10 border border-[#2b4635]/20 font-cinzel text-[8.5px] tracking-[0.22em] text-[#2b4635] uppercase font-semibold">
            <Sparkles className="w-3 h-3 text-[#a07820]" />
            <span>{wishes.length} {wishes.length === 1 ? 'BLESSING' : 'BLESSINGS'} RECEIVED</span>
          </span>
        </div>

        {/* Wishes Cards Grid */}
        <div className="max-w-lg mx-auto space-y-3.5 text-left">
          {wishes.length === 0 ? (
            <div className="text-center py-10 px-4 rounded-xl border border-dashed border-[rgba(160,120,32,0.3)] bg-[#faf5e9]/40">
              <p className="font-cormorant italic text-[18px] text-[#5b6840]">
                No wishes posted yet — be the first to bless Blesson &amp; Glinta!
              </p>
            </div>
          ) : (
            visibleWishes.map((item) => {
              const isLiked = !!likedMap[item.id];
              const initial = item.author.trim() ? item.author.trim()[0].toUpperCase() : 'G';
              return (
                <div
                  key={item.id}
                  className="sara-card p-4 sm:p-5 transition-all duration-200 hover:shadow-md"
                >
                  <div className="flex items-center justify-between gap-3 mb-2.5">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-[#2b4635] to-[#a07820] text-[#faf5e9] flex items-center justify-center font-italiana text-lg shadow-sm">
                        {initial}
                      </div>
                      <div>
                        <h4 className="font-cormorant font-bold text-[18px] text-[#2b4635] leading-tight">
                          {item.author}
                        </h4>
                        <p className="font-cinzel text-[8px] tracking-[0.22em] text-[#5b6840] uppercase mt-0.5">
                          {item.relation} &bull; {item.createdAt}
                        </p>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => handleToggleLike(item.id)}
                      className={`flex items-center gap-1 text-[11px] px-2.5 py-1 rounded-full border transition-all cursor-pointer ${
                        isLiked
                          ? 'border-[#7d2233] bg-[#7d2233]/10 text-[#7d2233]'
                          : 'border-[rgba(160,120,32,0.25)] text-[#5b6840] hover:text-[#2b4635]'
                      }`}
                    >
                      <Heart className={`w-3.5 h-3.5 ${isLiked ? 'fill-[#7d2233]' : ''}`} />
                      <span className="font-semibold">{item.likes}</span>
                    </button>
                  </div>

                  <p className="font-cormorant italic text-[16.5px] text-[#2b4635] leading-relaxed pl-13">
                    “{item.message}”
                  </p>
                </div>
              );
            })
          )}

          {/* Load More Button */}
          {wishes.length > visibleCount && (
            <div className="text-center pt-3">
              <button
                type="button"
                onClick={() => setVisibleCount((prev) => prev + 4)}
                className="font-cinzel text-[9px] tracking-[0.25em] text-[#2b4635] hover:text-[#a07820] px-5 py-2 rounded-full border border-[rgba(160,120,32,0.4)] bg-[#faf5e9] transition-all cursor-pointer font-semibold"
              >
                LOAD MORE BLESSINGS
              </button>
            </div>
          )}
        </div>
      </div>
    </section>
  );
};
