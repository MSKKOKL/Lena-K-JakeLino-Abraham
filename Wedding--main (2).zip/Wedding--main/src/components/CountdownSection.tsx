import React, { useState, useEffect } from 'react';
import { Calendar } from 'lucide-react';
import { WEDDING_DETAILS } from '../data/weddingData';
import { calculateTimeRemaining, padZero, TimeRemaining, generateGoogleCalendarUrl } from '../utils/countdown';

export const CountdownSection: React.FC = () => {
  const [timeLeft, setTimeLeft] = useState<TimeRemaining>(() =>
    calculateTimeRemaining(WEDDING_DETAILS.targetDateISO)
  );

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft(calculateTimeRemaining(WEDDING_DETAILS.targetDateISO));
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const googleCalUrl = generateGoogleCalendarUrl({
    title: `Holy Wedding · Blesson & Glinta`,
    details: `Holy Wedding from 11:30 AM at Stay Samara, Kottayam.`,
    location: `${WEDDING_DETAILS.venueName}, ${WEDDING_DETAILS.venueLocation}`,
    startDate: '2026-12-07T06:00:00.000Z',
    endDate: '2026-12-07T10:30:00.000Z',
  });

  return (
    <section className="relative w-full text-center border-b border-[#a07820]/25 bg-transparent overflow-hidden">
      {/* 1. Solid Forest Green Date Banner matching Screenshot 2 */}
      <div className="w-full bg-[#2b4635] py-5 px-6 text-center shadow-inner">
        <div className="font-cinzel tracking-[0.42em] text-[11px] sm:text-[12px] text-[#faf5e9] font-medium">
          7 DECEMBER 2026
        </div>
        <div className="font-cinzel tracking-[0.42em] text-[10px] sm:text-[11px] text-[#ecdcc0] mt-1.5 opacity-90">
          KOTTAYAM &nbsp;&bull;&nbsp; KERALA
        </div>
      </div>

      {/* 2. Big 3-Column Numbers: DAY | MONTH | YEAR matching Screenshot 2 */}
      <div className="flex items-stretch justify-center py-9 px-4 max-w-md mx-auto">
        {/* DAY */}
        <div className="flex-1 text-center px-2">
          <div className="font-italiana text-[54px] sm:text-[76px] text-[#2b4635] leading-none">
            07
          </div>
          <div className="font-cinzel text-[8.5px] tracking-[0.32em] text-[#5b6840] mt-2.5 font-semibold">
            DAY
          </div>
        </div>

        {/* Divider hairline */}
        <div className="w-[1px] bg-[#a07820]/30 my-2" />

        {/* MONTH */}
        <div className="flex-1 text-center px-2">
          <div className="font-italiana text-[54px] sm:text-[76px] text-[#2b4635] leading-none">
            12
          </div>
          <div className="font-cinzel text-[8.5px] tracking-[0.32em] text-[#5b6840] mt-2.5 font-semibold">
            MONTH
          </div>
        </div>

        {/* Divider hairline */}
        <div className="w-[1px] bg-[#a07820]/30 my-2" />

        {/* YEAR */}
        <div className="flex-1 text-center px-2">
          <div className="font-italiana text-[54px] sm:text-[76px] text-[#2b4635] leading-none">
            26
          </div>
          <div className="font-cinzel text-[8.5px] tracking-[0.32em] text-[#5b6840] mt-2.5 font-semibold">
            YEAR
          </div>
        </div>
      </div>

      {/* 3. HIS WORD section matching Screenshot 2 */}
      <div className="py-12 px-6 sm:px-10 max-w-md mx-auto flex flex-col items-center">
        <div className="section-eyebrow">— HIS WORD —</div>

        {/* Verse Block with gold left border matching Sara weds Isaac */}
        <div className="bg-[#2b4635]/[0.06] border-l-[3px] border-[#a07820] p-6 my-2 w-full text-left rounded-r-lg shadow-sm">
          <p className="font-cormorant italic text-[19px] sm:text-[20px] text-[#2b4635] leading-[1.75] mb-2 font-medium">
            &ldquo;From little hello’s to endless talks what started as a simple connection, slowly became our forever affection.&rdquo;
          </p>
          <span className="font-cinzel text-[9px] tracking-[0.32em] text-[#7d2233] opacity-85 block font-semibold">
            A COVENANT OF LOVE
          </span>
        </div>

        {/* Live Countdown to Holy Wedding */}
        <div className="font-cinzel text-[9px] tracking-[0.38em] text-[#7d2233] mt-8 mb-3 font-semibold">
          COUNTING DOWN TO THE HOLY WEDDING
        </div>

        <div className="w-full grid grid-cols-4 gap-2.5 sm:gap-3 my-2">
          <div className="p-3 sm:p-4 rounded-xl bg-[#fffdf7] border border-[#a07820]/25 shadow-sm text-center">
            <span className="font-italiana text-3xl sm:text-4xl text-[#2b4635] font-normal leading-none block">
              {padZero(timeLeft.days)}
            </span>
            <span className="font-cinzel text-[8px] tracking-[0.25em] text-[#5b6840] mt-1.5 block">
              DAYS
            </span>
          </div>

          <div className="p-3 sm:p-4 rounded-xl bg-[#fffdf7] border border-[#a07820]/25 shadow-sm text-center">
            <span className="font-italiana text-3xl sm:text-4xl text-[#2b4635] font-normal leading-none block">
              {padZero(timeLeft.hours)}
            </span>
            <span className="font-cinzel text-[8px] tracking-[0.25em] text-[#5b6840] mt-1.5 block">
              HOURS
            </span>
          </div>

          <div className="p-3 sm:p-4 rounded-xl bg-[#fffdf7] border border-[#a07820]/25 shadow-sm text-center">
            <span className="font-italiana text-3xl sm:text-4xl text-[#2b4635] font-normal leading-none block">
              {padZero(timeLeft.minutes)}
            </span>
            <span className="font-cinzel text-[8px] tracking-[0.25em] text-[#5b6840] mt-1.5 block">
              MINS
            </span>
          </div>

          <div className="p-3 sm:p-4 rounded-xl bg-[#fffdf7] border border-[#a07820]/25 shadow-sm text-center">
            <span className="font-italiana text-3xl sm:text-4xl text-[#a07820] font-normal leading-none block">
              {padZero(timeLeft.seconds)}
            </span>
            <span className="font-cinzel text-[8px] tracking-[0.25em] text-[#a07820] mt-1.5 block">
              SECS
            </span>
          </div>
        </div>

        {/* Date Reminder & Add to Calendar */}
        <div className="mt-5 pt-4 border-t border-[#a07820]/20 flex flex-col sm:flex-row items-center justify-between gap-3 w-full text-xs font-cormorant text-[#2b4635]">
          <div className="text-center sm:text-left">
            <span className="font-semibold block text-sm">7 December 2026 &bull; 11:30 AM</span>
            <span className="text-[#5b6840] text-xs">Stay Samara, Kottayam</span>
          </div>

          <a
            href={googleCalUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-full border border-[#a07820]/50 hover:bg-[#2b4635] hover:text-[#faf5e9] text-[#2b4635] font-cinzel text-[9.5px] tracking-wider uppercase transition-all shadow-sm cursor-pointer"
          >
            <Calendar className="w-3.5 h-3.5 text-[#a07820]" />
            <span>SAVE TO CALENDAR</span>
          </a>
        </div>

        {/* Divider */}
        <div className="divider">
          <span />
          <div className="dot" />
          <span />
        </div>
      </div>
    </section>
  );
};
