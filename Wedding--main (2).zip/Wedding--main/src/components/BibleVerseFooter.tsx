import React from 'react';
import { MessageCircle, Instagram } from 'lucide-react';
import { AdminPortal } from './AdminPortal';

export const BibleVerseFooter: React.FC = () => {
  return (
    <footer className="relative w-full bg-transparent text-[#2b4635] pt-12 pb-8 px-6 text-center">
      <div className="max-w-xl mx-auto flex flex-col items-center">
        {/* Contact Section */}
        <div className="w-full mb-12">
          <div className="section-eyebrow">— GET IN TOUCH —</div>
          <h3 className="section-title text-3xl sm:text-4xl mb-2">Need Any Help?</h3>
          <p className="font-cormorant italic text-[17.5px] text-[#5b6840] font-semibold max-w-sm mx-auto mb-6">
            Feel free to reach out to us directly for directions, venue assistance, or wedding details.
          </p>

          <div className="max-w-md mx-auto grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            <a
              href="https://wa.me/919072256228?text=Hello%20Blesson%20%26%20Glinta!"
              target="_blank"
              rel="noopener noreferrer"
              className="sara-card flex items-center gap-3.5 p-3.5 text-left transition-all duration-200 hover:border-[#2b4635]/40 hover:-translate-y-0.5 cursor-pointer"
            >
              <div className="w-10 h-10 rounded-full bg-[#2b4635]/10 text-[#2b4635] flex items-center justify-center shrink-0">
                <MessageCircle className="w-5 h-5 text-[#2b4635]" />
              </div>
              <div>
                <p className="font-cinzel text-[8px] tracking-[0.24em] text-[#5b6840] uppercase mb-0.5 font-semibold">
                  WHATSAPP
                </p>
                <p className="font-cormorant text-[17.5px] font-bold text-[#2b4635] leading-tight">
                  +91 90722 56228
                </p>
              </div>
            </a>

            <a
              href="https://wa.me/919539577574?text=Hello%20Blesson%20%26%20Glinta!"
              target="_blank"
              rel="noopener noreferrer"
              className="sara-card flex items-center gap-3.5 p-3.5 text-left transition-all duration-200 hover:border-[#2b4635]/40 hover:-translate-y-0.5 cursor-pointer"
            >
              <div className="w-10 h-10 rounded-full bg-[#2b4635]/10 text-[#2b4635] flex items-center justify-center shrink-0">
                <MessageCircle className="w-5 h-5 text-[#2b4635]" />
              </div>
              <div>
                <p className="font-cinzel text-[8px] tracking-[0.24em] text-[#5b6840] uppercase mb-0.5 font-semibold">
                  WHATSAPP
                </p>
                <p className="font-cormorant text-[17.5px] font-bold text-[#2b4635] leading-tight">
                  +91 9539577574
                </p>
              </div>
            </a>
          </div>
        </div>

        <div className="divider mb-10 w-full">
          <span />
          <div className="dot" />
          <span />
        </div>

        {/* Monogram Crest */}
        <div className="mb-6">
          <svg width="68" height="68" viewBox="0 0 100 100" className="mx-auto text-[#a07820]">
            <circle cx="50" cy="50" r="46" fill="none" stroke="currentColor" strokeWidth="1.2" strokeDasharray="3 3" />
            <circle cx="50" cy="50" r="41" fill="none" stroke="currentColor" strokeWidth="0.8" />
            <text x="50" y="55" textAnchor="middle" fontFamily="'Italiana', serif" fontSize="24" fill="#2b4635">
              B &amp; G
            </text>
            <text x="50" y="73" textAnchor="middle" fontFamily="'Cinzel', serif" fontSize="6.5" letterSpacing="0.25em" fill="#a07820">
              DEC 2026
            </text>
          </svg>
        </div>

        {/* Scripture Blessing */}
        <div className="space-y-1 mb-8 max-w-md">
          <p className="font-cormorant italic text-xl sm:text-2xl text-[#2b4635] leading-relaxed">
            &ldquo;This was the Lord’s doing; it is marvelous in our eyes.&rdquo;
          </p>
          <p className="font-cinzel text-[9.5px] tracking-[0.3em] text-[#a07820] uppercase font-semibold">
            Psalm 118 : 23
          </p>
        </div>

        {/* Couple Signoff */}
        <div className="space-y-1 mb-6">
          <p className="font-italiana text-3xl sm:text-4xl text-[#2b4635]">
            Blesson <span className="font-playfair italic font-normal text-[#a07820] text-2xl">&amp;</span> Glinta
          </p>
          <p className="font-cinzel text-[9.5px] tracking-[0.24em] text-[#5b6840] uppercase">
            Monday, 7 December 2026 &bull; Stay Samara, Kottayam
          </p>
        </div>

        <p className="font-cormorant italic text-[16px] text-[#5b6840] max-w-sm mb-6">
          With love, prayers, and gratitude from both our families.
        </p>

        {/* Discreet Admin Lock ABOVE web support */}
        <div className="mt-4 mb-2">
          <AdminPortal triggerType="icon" />
        </div>

        {/* Subtle Web Support Option (Icons only) */}
        <div className="pt-4 pb-2 border-t border-[rgba(160,120,32,0.18)] w-full max-w-[180px] mx-auto flex flex-col items-center gap-1.5 opacity-75 hover:opacity-100 transition-opacity">
          <span className="font-cinzel text-[7px] tracking-[0.28em] text-[#5b6840] uppercase">
            WEB SUPPORT
          </span>
          <div className="flex items-center justify-center gap-3">
            <a
              href="https://wa.me/919400630769?text=Hello%20Web%20Support"
              target="_blank"
              rel="noopener noreferrer"
              aria-label="WhatsApp Support"
              title="WhatsApp: 94006 30769"
              className="w-7 h-7 rounded-full bg-[#2b4635]/10 hover:bg-[#2b4635] text-[#2b4635] hover:text-[#faf5e9] flex items-center justify-center transition-all duration-300 shadow-2xs hover:scale-110 cursor-pointer"
            >
              <MessageCircle className="w-3.5 h-3.5" />
            </a>

            <a
              href="https://instagram.com/raxhi_z_"
              target="_blank"
              rel="noopener noreferrer"
              aria-label="Instagram Support"
              title="Instagram: raxhi_z_"
              className="w-7 h-7 rounded-full bg-[#2b4635]/10 hover:bg-[#2b4635] text-[#2b4635] hover:text-[#faf5e9] flex items-center justify-center transition-all duration-300 shadow-2xs hover:scale-110 cursor-pointer"
            >
              <Instagram className="w-3.5 h-3.5" />
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
};
