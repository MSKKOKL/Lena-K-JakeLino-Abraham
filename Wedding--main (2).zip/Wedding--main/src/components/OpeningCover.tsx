import React, { useState, useEffect } from 'react';
import confetti from 'canvas-confetti';
import { calculateTimeRemaining, padZero, TimeRemaining } from '../utils/countdown';
import { WEDDING_DETAILS } from '../data/weddingData';

interface OpeningCoverProps {
  onOpen: () => void;
  isOpen: boolean;
}

export const OpeningCover: React.FC<OpeningCoverProps> = ({ onOpen, isOpen }) => {
  const [timeLeft, setTimeLeft] = useState<TimeRemaining>(() =>
    calculateTimeRemaining(WEDDING_DETAILS.targetDateISO)
  );

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft(calculateTimeRemaining(WEDDING_DETAILS.targetDateISO));
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  if (isOpen) return null;

  const handleOpenClick = () => {
    confetti({
      particleCount: 65,
      spread: 75,
      origin: { y: 0.6 },
      colors: ['#7d2233', '#a07820', '#2b4635', '#ffffff'],
    });
    onOpen();
  };

  return (
    <div
      role="dialog"
      aria-label="Wedding Invitation Envelope"
      className="fixed inset-0 z-[1000] bg-transparent text-center overflow-y-auto select-none"
    >
      {/* Watercolor Cloud Background with Paper Grain */}
      <div className="cloud-bg in-landing" aria-hidden="true">
        <svg className="w-full h-full" xmlns="http://www.w3.org/2000/svg">
          <rect width="100%" height="100%" fill="transparent" />
          <rect width="100%" height="100%" filter="url(#wc-clouds)" />
          <rect width="100%" height="100%" filter="url(#paper-grain)" />
        </svg>
      </div>

      {/* Opening page transparent background photo: IMG_1974 watercolor illustration */}
      <div className="fixed inset-0 pointer-events-none z-[1] overflow-hidden">
        <img
          src="/assets/aistudio/IMG_1974_89651bf4.JPG"
          alt=""
          aria-hidden="true"
          className="w-full h-full object-cover object-[50%_35%] opacity-35"
        />
        <div className="absolute inset-0 bg-[#f2ebda]/55 backdrop-blur-[0.3px]" />
      </div>

      {/* Outer & Inner Framed Borders matching IMG_20261108_170744 */}
      <div className="fixed top-[22px] left-[22px] right-[22px] bottom-[22px] border border-[#2b4635]/35 pointer-events-none z-[2]" />
      <div className="fixed top-[30px] left-[30px] right-[30px] bottom-[30px] border border-[#2b4635]/15 pointer-events-none z-[2]" />

      {/* Gold Corner Bracket Ornaments matching reference */}
      <div className="fixed top-[30px] left-[30px] w-14 h-14 border-t-[2.5px] border-l-[2.5px] border-[#a07820] pointer-events-none z-[3]" />
      <div className="fixed top-[30px] right-[30px] w-14 h-14 border-t-[2.5px] border-r-[2.5px] border-[#a07820] pointer-events-none z-[3]" />
      <div className="fixed bottom-[30px] left-[30px] w-14 h-14 border-bottom-[2.5px] border-b-[2.5px] border-l-[2.5px] border-[#a07820] pointer-events-none z-[3]" />
      <div className="fixed bottom-[30px] right-[30px] w-14 h-14 border-b-[2.5px] border-r-[2.5px] border-[#a07820] pointer-events-none z-[3]" />

      {/* Top-Left Authentic Line-Art Interlocking Hearts Sticker */}
      <img
        src="/assets/hearts-corner.png"
        alt=""
        aria-hidden="true"
        className="fixed top-[46px] left-[44px] w-[50px] sm:w-[60px] h-auto pointer-events-none z-[5]"
        style={{ filter: 'hue-rotate(-84deg) saturate(.85)' }}
      />

      {/* Top-Right Authentic Line-Art Wedding Couple Sketch Sticker */}
      <img
        src="/assets/couple-corner.png"
        alt=""
        aria-hidden="true"
        className="fixed top-[38px] right-[40px] w-[52px] sm:w-[62px] h-auto pointer-events-none z-[5]"
        style={{ filter: 'hue-rotate(-84deg) saturate(.85)' }}
      />

      {/* Live Green Status Indicator Dot on Right Edge */}
      <div
        className="fixed top-[74px] right-[22px] w-3 h-3 rounded-full bg-[#9dbe43] border border-[#2b4635] shadow-[0_0_8px_rgba(157,190,67,0.7)] pointer-events-none z-[6]"
        aria-hidden="true"
      />

      {/* Centered Landing Content */}
      <div className="relative z-[10] min-h-full flex flex-col items-center justify-center py-12 px-6 sm:px-10 max-w-lg mx-auto">
        {/* Transparent Monogram Letter Logo matching uploaded screenshot */}
        <div className="relative mb-4 flex justify-center">
          <svg width="86" height="86" viewBox="0 0 100 100" className="mx-auto text-[#a07820] transition-transform duration-500 hover:scale-105">
            <circle cx="50" cy="50" r="46" fill="none" stroke="currentColor" strokeWidth="1.2" strokeDasharray="3 3" />
            <circle cx="50" cy="50" r="41" fill="none" stroke="currentColor" strokeWidth="0.8" />
            <text x="50" y="55" textAnchor="middle" fontFamily="'Italiana', serif" fontSize="24" fill="#2b4635">
              B &amp; G
            </text>
            <text x="50" y="73" textAnchor="middle" fontFamily="'Cinzel', serif" fontSize="6.5" letterSpacing="0.25em" fill="#a07820">
              DEC 2026
            </text>
          </svg>
        </div>

        {/* Scripture Verse Line in Raspberry Italic */}
        <div className="font-cormorant italic text-[17px] sm:text-[18.5px] text-[#7d2233] leading-relaxed mb-3 max-w-[34ch]">
          &ldquo;This was the Lord’s doing;
          <br />
          it is marvelous in our eyes.&rdquo;
          <br />
          <span className="font-cinzel not-italic text-[8.5px] tracking-[0.34em] opacity-80 block mt-1.5 text-[#2b4635]">
            PSALM 118 : 23
          </span>
        </div>

        {/* Couple Names in Italiana font with red ampersand */}
        <h1 className="font-italiana text-[56px] sm:text-[76px] leading-[0.88] text-[#2b4635] my-1">
          Blesson
          <span className="font-playfair italic text-[#7d2233] block text-[0.45em] my-0.5 sm:my-1">
            &amp;
          </span>
          Glinta
        </h1>

        {/* Couple Quote Tagline */}
        <p className="font-cormorant italic text-[15px] sm:text-[16px] text-[#4a5568] my-3 max-w-[36ch] leading-relaxed">
          &ldquo;From little hello’s to endless talks what started as a simple connection, slowly became our forever affection.&rdquo;
        </p>

        {/* Big Date in Crimson/Red */}
        <div className="font-cinzel text-[17px] sm:text-[20px] tracking-[0.32em] text-[#7d2233] font-semibold my-2">
          7 DECEMBER 2026
        </div>

        {/* Divider with Center Dot */}
        <div className="flex items-center justify-center gap-2.5 my-2">
          <span className="w-[50px] h-[1px] bg-[#a07820] opacity-40" />
          <div className="w-[5px] h-[5px] rounded-full bg-[#9dbe43]" />
          <span className="w-[50px] h-[1px] bg-[#a07820] opacity-40" />
        </div>

        {/* Countdown Eyebrow */}
        <div className="font-cinzel text-[8.5px] tracking-[0.42em] text-[#7d2233] mb-1">
          C O U N T I N G   D O W N
        </div>

        {/* Countdown Digits */}
        <div className="flex items-start justify-center gap-2.5 sm:gap-4 my-2 mb-5">
          <div className="text-center min-w-[46px]">
            <div className="font-italiana text-3xl sm:text-4xl text-[#2b4635] leading-none">
              {padZero(timeLeft.days)}
            </div>
            <div className="font-cinzel text-[7.5px] tracking-[0.26em] text-[#5b6840] mt-1.5">
              DAYS
            </div>
          </div>
          <div className="font-italiana text-2xl sm:text-3xl text-[#7d2233] leading-none">·</div>
          <div className="text-center min-w-[46px]">
            <div className="font-italiana text-3xl sm:text-4xl text-[#2b4635] leading-none">
              {padZero(timeLeft.hours)}
            </div>
            <div className="font-cinzel text-[7.5px] tracking-[0.26em] text-[#5b6840] mt-1.5">
              HRS
            </div>
          </div>
          <div className="font-italiana text-2xl sm:text-3xl text-[#7d2233] leading-none">·</div>
          <div className="text-center min-w-[46px]">
            <div className="font-italiana text-3xl sm:text-4xl text-[#2b4635] leading-none">
              {padZero(timeLeft.minutes)}
            </div>
            <div className="font-cinzel text-[7.5px] tracking-[0.26em] text-[#5b6840] mt-1.5">
              MINS
            </div>
          </div>
          <div className="font-italiana text-2xl sm:text-3xl text-[#7d2233] leading-none">·</div>
          <div className="text-center min-w-[46px]">
            <div className="font-italiana text-3xl sm:text-4xl text-[#2b4635] leading-none">
              {padZero(timeLeft.seconds)}
            </div>
            <div className="font-cinzel text-[7.5px] tracking-[0.26em] text-[#5b6840] mt-1.5">
              SECS
            </div>
          </div>
        </div>

        {/* Enter Button in Forest Spruce Green with Arrow */}
        <button
          onClick={handleOpenClick}
          type="button"
          className="inline-flex items-center gap-2.5 px-9 py-3.5 bg-[#2b4635] hover:bg-[#3a5c46] text-[#faf5e9] font-cinzel text-[10px] tracking-[0.28em] transition-all rounded-[3px] shadow-[0_10px_28px_rgba(43,70,53,0.3)] hover:scale-102 active:scale-98 cursor-pointer"
        >
          <span>OPEN INVITATION</span>
          <span>&rarr;</span>
        </button>

        {/* Venue line */}
        <div className="font-cinzel text-[8px] tracking-[0.38em] text-[#4a5568] mt-4 uppercase">
          STAY SAMARA · KOTTAYAM, KERALA
        </div>
      </div>
    </div>
  );
};
