import React, { useState, useEffect } from 'react';
import { Lock, X, Shield, Copy, Check, Users } from 'lucide-react';
import { collection, onSnapshot } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import { RsvpEntry } from '../types';

interface AdminPortalProps {
  triggerType?: 'icon' | 'rsvp-link';
}

export const AdminPortal: React.FC<AdminPortalProps> = ({ triggerType = 'icon' }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [passcode, setPasscode] = useState('');
  const [isUnlocked, setIsUnlocked] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [copiedList, setCopiedList] = useState(false);

  // Stored RSVP entries synced with Firestore and local cache
  const [rsvps, setRsvps] = useState<RsvpEntry[]>(() => {
    try {
      const saved = localStorage.getItem('blesson_glinta_all_rsvps');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Real-time Firestore sync for guest list
  useEffect(() => {
    const unsub = onSnapshot(
      collection(db, 'rsvps'),
      (snapshot) => {
        const list: RsvpEntry[] = snapshot.docs.map((docSnap) => {
          const data = docSnap.data();
          return {
            id: docSnap.id,
            fullName: data.name || '',
            whatsapp: data.phone || '',
            side: (data.side === 'bride' ? 'bride' : 'groom') as 'bride' | 'groom',
            attendingCeremony: data.attendingCeremony ?? true,
            attendingReception: data.attendingReception ?? true,
            guestCount: data.guestsCount || 1,
            message: data.message || '',
            createdAt: data.createdAt || new Date().toISOString(),
          };
        });

        list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

        if (list.length > 0) {
          setRsvps(list);
          try {
            localStorage.setItem('blesson_glinta_all_rsvps', JSON.stringify(list));
          } catch {
            // ignore
          }
        }
      },
      (err) => {
        console.warn('Admin portal Firestore sync warning:', err);
        handleFirestoreError(err, OperationType.GET, 'rsvps');
      }
    );

    return () => unsub();
  }, []);

  const handleUnlock = (e: React.FormEvent) => {
    e.preventDefault();
    const clean = passcode.trim();
    if (clean === '2026' || clean.toLowerCase() === 'admin') {
      setIsUnlocked(true);
      setError(null);
    } else {
      setError('Incorrect passcode. Access is restricted to wedding hosts.');
    }
  };

  const copyGuestList = () => {
    if (rsvps.length === 0) return;
    const text = rsvps
      .map(
        (g, i) =>
          `${i + 1}. ${g.fullName} (${g.whatsapp}) - ${g.side?.toUpperCase()} Family - Guests: ${g.guestCount} - Ceremony: ${g.attendingCeremony ? 'Yes' : 'No'}`
      )
      .join('\n');
    navigator.clipboard.writeText(text);
    setCopiedList(true);
    setTimeout(() => setCopiedList(false), 2500);
  };

  const totalGuests = rsvps.reduce((acc, curr) => acc + (curr.guestCount || 1), 0);

  return (
    <>
      {/* Trigger button */}
      {triggerType === 'rsvp-link' ? (
        <button
          onClick={() => setIsOpen(true)}
          type="button"
          aria-label="Host Portal - View RSVPs"
          title="Host Portal - View RSVPs"
          className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full border border-[rgba(160,120,32,0.3)] bg-[#faf5e9]/70 hover:bg-[#faf5e9] text-[#5b6840] hover:text-[#2b4635] font-cinzel text-[8.5px] tracking-[0.2em] transition-all cursor-pointer shadow-xs"
        >
          <Lock className="w-3 h-3 text-[#a07820]" />
          <span>HOST ACCESS · VIEW RSVPS</span>
        </button>
      ) : (
        <div className="flex justify-center items-center py-2">
          <button
            onClick={() => setIsOpen(true)}
            type="button"
            aria-label="Host Portal"
            title="Host Portal"
            className="p-2 rounded-full text-[#2b4635]/30 hover:text-[#a07820] hover:bg-[#2b4635]/5 transition-all duration-300 cursor-pointer"
          >
            <Lock className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Admin Portal Modal */}
      {isOpen && (
        <div
          role="dialog"
          aria-label="Host Portal"
          className="fixed inset-0 z-[90] bg-black/95 flex items-center justify-center p-4 backdrop-blur-md animate-fadeIn"
        >
          <div className="relative w-full max-w-md bg-[#161514] border border-white/20 rounded-2xl shadow-2xl p-5 max-h-[90vh] flex flex-col text-left">
            <button
              onClick={() => {
                setIsOpen(false);
                setIsUnlocked(false);
                setPasscode('');
                setError(null);
              }}
              aria-label="Close Portal"
              className="absolute top-4 right-4 p-1.5 rounded-full bg-white/10 hover:bg-white/20 text-white cursor-pointer transition-colors"
            >
              <X className="w-4 h-4" />
            </button>

            <div className="flex items-center gap-2 mb-4">
              <Shield className="w-5 h-5 text-[#d4af37]" />
              <h4 className="font-caps text-lg text-white font-semibold tracking-wide">
                Host &amp; Family Portal
              </h4>
            </div>

            {!isUnlocked ? (
              <form onSubmit={handleUnlock} className="space-y-4 py-4">
                <p className="text-xs text-white/70">
                  Enter host passcode to view confirmed guest attendance and details.
                </p>

                {error && (
                  <p className="text-xs text-rose-400 bg-rose-500/10 p-2.5 rounded-lg border border-rose-500/20">
                    {error}
                  </p>
                )}

                <div>
                  <label className="text-[10px] font-semibold tracking-wider uppercase text-white/60 block mb-1">
                    Host Passcode
                  </label>
                  <input
                    type="password"
                    value={passcode}
                    onChange={(e) => setPasscode(e.target.value)}
                    placeholder="Enter passcode..."
                    className="w-full px-3 py-2.5 rounded-xl bg-white/5 border border-white/20 text-white text-xs focus:outline-none focus:border-[#d4af37]"
                    autoFocus
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-2.5 rounded-full bg-[#d4af37] hover:bg-[#c49f2b] text-black font-semibold text-xs tracking-wider uppercase transition-all cursor-pointer shadow-lg"
                >
                  Unlock Portal
                </button>
              </form>
            ) : (
              <div className="flex flex-col flex-1 overflow-hidden space-y-4">
                {/* Summary Metrics */}
                <div className="grid grid-cols-2 gap-3">
                  <div className="p-3 rounded-xl bg-white/5 border border-white/10 text-center">
                    <span className="text-[10px] uppercase tracking-wider text-white/50 block">
                      Confirmed RSVPs
                    </span>
                    <span className="font-caps text-2xl text-white font-semibold">
                      {rsvps.length}
                    </span>
                  </div>

                  <div className="p-3 rounded-xl bg-white/5 border border-white/10 text-center">
                    <span className="text-[10px] uppercase tracking-wider text-[#d4af37] block">
                      Total Attending
                    </span>
                    <span className="font-caps text-2xl text-[#d4af37] font-semibold">
                      {totalGuests}
                    </span>
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-xs text-white/60 font-medium">
                    Guest Records ({rsvps.length})
                  </span>
                  {rsvps.length > 0 && (
                    <button
                      onClick={copyGuestList}
                      type="button"
                      className="inline-flex items-center gap-1 text-[11px] text-[#d4af37] hover:underline cursor-pointer"
                    >
                      {copiedList ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                      <span>{copiedList ? 'Copied!' : 'Copy Guest List'}</span>
                    </button>
                  )}
                </div>

                {/* Guest List Records */}
                <div className="flex-1 overflow-y-auto space-y-2.5 pr-1">
                  {rsvps.length === 0 ? (
                    <p className="text-xs text-white/50 text-center py-6">
                      No RSVPs submitted yet. As guests confirm, their names, WhatsApp contacts, and guest counts will appear here.
                    </p>
                  ) : (
                    rsvps.map((entry) => (
                      <div
                        key={entry.id}
                        className="p-3 rounded-xl bg-white/[0.04] border border-white/10 space-y-1 text-xs"
                      >
                        <div className="flex items-center justify-between">
                          <span className="font-semibold text-white">{entry.fullName}</span>
                          <span className="px-2 py-0.5 rounded-full text-[10px] uppercase font-semibold bg-white/10 text-[#d4af37]">
                            {entry.side}'s Family
                          </span>
                        </div>
                        <div className="text-white/70 flex items-center justify-between">
                          <a
                            href={`https://wa.me/${entry.whatsapp.replace(/\D/g, '')}`}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-[#25D366] hover:underline"
                          >
                            {entry.whatsapp}
                          </a>
                          <span className="text-white/90 font-medium">Guests: {entry.guestCount}</span>
                        </div>
                        <div className="text-[11px] text-white/50 flex gap-3 pt-0.5">
                          <span>Ceremony: {entry.attendingCeremony ? '✅ Yes' : '❌ No'}</span>
                          <span>Reception: {entry.attendingReception ? '✅ Yes' : '❌ No'}</span>
                        </div>
                        {entry.message && (
                          <p className="text-[11px] text-white/70 italic pt-1 border-t border-white/5">
                            "{entry.message}"
                          </p>
                        )}
                      </div>
                    ))
                  )}
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </>
  );
};
