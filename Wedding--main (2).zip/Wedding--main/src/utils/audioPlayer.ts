/**
 * Wedding Audio Player streaming authentic acoustic romance BGM from the reference site.
 */

const AUDIO_SRC = 'https://pub-bc01cea1ca914ad8aba6c7541c55c7fb.r2.dev/digiwed-invitations-sara-isaac-audio/bgm_track.mp3';

class WeddingAudioPlayer {
  private audio: HTMLAudioElement | null = null;
  private isPlaying: boolean = false;
  private hasInitialized: boolean = false;

  private initAudio() {
    if (this.hasInitialized && this.audio) return;
    try {
      this.audio = new Audio(AUDIO_SRC);
      this.audio.loop = true;
      this.audio.preload = 'auto';
      this.audio.volume = 0.65;

      this.audio.addEventListener('play', () => {
        this.isPlaying = true;
      });
      this.audio.addEventListener('pause', () => {
        this.isPlaying = false;
      });
      this.audio.addEventListener('ended', () => {
        this.isPlaying = false;
      });
      this.audio.addEventListener('error', (e) => {
        console.warn('Audio stream error, will retry on next user interaction', e);
      });

      this.hasInitialized = true;
    } catch (err) {
      console.warn('Could not initialize audio element:', err);
    }
  }

  public isAudioPlaying(): boolean {
    if (this.audio) {
      return !this.audio.paused && !this.audio.ended && this.audio.readyState > 2;
    }
    return this.isPlaying;
  }

  public start(): boolean {
    this.initAudio();
    if (!this.audio) return false;
    this.audio
      .play()
      .then(() => {
        this.isPlaying = true;
      })
      .catch((err) => {
        console.warn('Audio autoplay blocked or interrupted:', err);
        this.isPlaying = false;
      });
    return true;
  }

  public pause(): void {
    if (this.audio) {
      this.audio.pause();
      this.isPlaying = false;
    }
  }

  public toggle(): boolean {
    this.initAudio();
    if (!this.audio) return false;
    if (this.isAudioPlaying()) {
      this.pause();
      return false;
    } else {
      this.start();
      return true;
    }
  }
}

export const weddingAudio = new WeddingAudioPlayer();
