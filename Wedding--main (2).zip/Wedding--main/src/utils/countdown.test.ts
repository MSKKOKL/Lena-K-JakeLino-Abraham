import test from 'node:test';
import assert from 'node:assert/strict';
import { calculateTimeRemaining, padZero, generateGoogleCalendarUrl } from './countdown';

test('calculateTimeRemaining returns correct days, hours, mins, secs for future date', () => {
  const current = new Date('2026-11-07T10:00:00Z');
  const target = new Date('2026-12-07T11:30:00Z');

  const result = calculateTimeRemaining(target, current);

  assert.equal(result.days, 30);
  assert.equal(result.hours, 1);
  assert.equal(result.minutes, 30);
  assert.equal(result.seconds, 0);
  assert.equal(result.isPast, false);
});

test('calculateTimeRemaining marks isPast when current date is beyond target', () => {
  const current = new Date('2026-12-08T12:00:00Z');
  const target = new Date('2026-12-07T11:30:00Z');

  const result = calculateTimeRemaining(target, current);

  assert.equal(result.isPast, true);
  assert.equal(result.days, 1);
  assert.equal(result.hours, 0);
  assert.equal(result.minutes, 30);
});

test('padZero formats single and double digits properly', () => {
  assert.equal(padZero(0), '00');
  assert.equal(padZero(5), '05');
  assert.equal(padZero(12), '12');
  assert.equal(padZero(99), '99');
});

test('generateGoogleCalendarUrl creates valid calendar link with encoded parameters', () => {
  const link = generateGoogleCalendarUrl({
    title: 'Holy Wedding of Blesson & Glinta',
    details: 'Stay Samara, Kottayam',
    location: 'Stay Samara, Kottayam',
    startDate: '2026-12-07T06:00:00.000Z',
    endDate: '2026-12-07T10:00:00.000Z',
  });

  assert.match(link, /^https:\/\/calendar\.google\.com\/calendar\/render\?/);
  assert.match(link, /text=Holy\+Wedding\+of\+Blesson\+%26\+Glinta/);
  assert.match(link, /dates=20261207T060000Z%2F20261207T100000Z/);
});
