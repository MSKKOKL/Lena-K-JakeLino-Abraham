export interface TimeRemaining {
  days: number;
  hours: number;
  minutes: number;
  seconds: number;
  isPast: boolean;
  totalMs: number;
}

export function calculateTimeRemaining(targetDate: Date | string | number, currentDate: Date | string | number = new Date()): TimeRemaining {
  const targetTime = new Date(targetDate).getTime();
  const currentTime = new Date(currentDate).getTime();
  const diff = targetTime - currentTime;

  const isPast = diff < 0;
  const absMs = Math.abs(diff);

  const days = Math.floor(absMs / (1000 * 60 * 60 * 24));
  const hours = Math.floor((absMs % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  const minutes = Math.floor((absMs % (1000 * 60 * 60)) / (1000 * 60));
  const seconds = Math.floor((absMs % (1000 * 60)) / 1000);

  return {
    days,
    hours,
    minutes,
    seconds,
    isPast,
    totalMs: diff
  };
}

export function padZero(num: number): string {
  return String(num).padStart(2, '0');
}

export function generateGoogleCalendarUrl(event: {
  title: string;
  details: string;
  location: string;
  startDate: string;
  endDate: string;
}): string {
  const base = 'https://calendar.google.com/calendar/render?action=TEMPLATE';
  const formatTime = (dStr: string) => {
    const d = new Date(dStr);
    return d.toISOString().replace(/[-:]/g, '').replace(/\.\d{3}/, '');
  };

  const dates = `${formatTime(event.startDate)}/${formatTime(event.endDate)}`;
  const params = new URLSearchParams({
    text: event.title,
    details: event.details,
    location: event.location,
    dates: dates
  });

  return `${base}&${params.toString()}`;
}
