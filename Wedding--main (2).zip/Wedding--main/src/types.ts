export interface WeddingDetails {
  groom: {
    fullName: string;
    fatherName: string;
    motherName: string;
    origin: string;
  };
  bride: {
    fullName: string;
    fatherName: string;
    motherName: string;
    origin: string;
  };
  quote: string;
  dateStr: string;
  targetDateISO: string;
  venueName: string;
  venueLocation: string;
  holyWeddingTime: string;
  mapQuery: string;
}

export interface RsvpEntry {
  id: string;
  fullName: string;
  whatsapp: string;
  side: 'bride' | 'groom';
  attendingCeremony: boolean;
  attendingReception: boolean;
  guestCount: number;
  message?: string;
  createdAt: string;
}

export interface WishEntry {
  id: string;
  author: string;
  relation: string;
  message: string;
  likes: number;
  createdAt: string;
}

export interface GalleryPhoto {
  id: string;
  url: string;
  title: string;
  caption: string;
  tag: string;
}
