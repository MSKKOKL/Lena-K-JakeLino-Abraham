import React, { useState, useEffect } from 'react';
import { OpeningCover } from './components/OpeningCover';
import { HeroSection } from './components/HeroSection';
import { StoryArtworkSection } from './components/StoryArtworkSection';
import { CountdownSection } from './components/CountdownSection';
import { ParentsSection } from './components/ParentsSection';
import { EventDetailsSection } from './components/EventDetailsSection';
import { GallerySection } from './components/GallerySection';
import { RsvpSection } from './components/RsvpSection';
import { WishesGuestbook } from './components/WishesGuestbook';
import { BibleVerseFooter } from './components/BibleVerseFooter';
import { MusicController } from './components/MusicController';
import { PetalField } from './components/PetalField';
import { weddingAudio } from './utils/audioPlayer';

export default function App() {
  const [isOpen, setIsOpen] = useState(false);
  const [showStickyBadge, setShowStickyBadge] = useState(false);

  // Check URL parameters (e.g. ?autostart=1 to bypass cover during testing)
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    if (params.get('autostart') === '1') {
      setIsOpen(true);
    }
  }, []);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 280) {
        setShowStickyBadge(true);
      } else {
        setShowStickyBadge(false);
      }
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleOpenInvitation = () => {
    setIsOpen(true);
    // Automatically play the authentic reference acoustic wedding music track
    weddingAudio.start();
  };

  const scrollToSection = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="relative min-h-screen bg-[#f2ebda] text-[#2b4635] selection:bg-[#7d2233]/20 selection:text-[#2b4635] overflow-x-hidden">
      {/* 1. TEXTURED WATERCOLOR CLOUD & PAPER GRAIN BACKGROUND */}
      <div className="cloud-bg" aria-hidden="true">
        <svg xmlns="http://www.w3.org/2000/svg">
          <defs>
            <filter id="wc-clouds" x="-20%" y="-20%" width="140%" height="140%" colorInterpolationFilters="sRGB">
              <feTurbulence type="fractalNoise" baseFrequency="0.009 0.013" numOctaves="4" seed="14" stitchTiles="stitch" result="n" />
              <feColorMatrix in="n" type="matrix" values="0 0 0 0 1  0 0 0 0 0.99  0 0 0 0 0.96  0 0 0 -2.3 1.6" result="m" />
              <feGaussianBlur in="m" stdDeviation="1.8" />
            </filter>
            <filter id="paper-grain" x="0" y="0" width="100%" height="100%" colorInterpolationFilters="sRGB">
              <feTurbulence type="fractalNoise" baseFrequency="0.85" numOctaves="3" seed="7" stitchTiles="stitch" result="g" />
              <feColorMatrix in="g" type="matrix" values="0 0 0 0 .55  0 0 0 0 .46  0 0 0 0 .29  0 0 0 .16 0" />
            </filter>
          </defs>
          <rect width="100%" height="100%" fill="transparent" />
          <rect width="100%" height="100%" filter="url(#wc-clouds)" />
          <rect width="100%" height="100%" filter="url(#paper-grain)" />
        </svg>
      </div>

      {/* 2. HAND-DRAWN MOUNTAIN & HORIZON CONTOUR BACKGROUND */}
      <div className="fixed inset-0 z-[1] pointer-events-none overflow-hidden" aria-hidden="true">
        <svg
          viewBox="0 0 800 500"
          className="absolute bottom-0 left-0 w-full h-auto"
          xmlns="http://www.w3.org/2000/svg"
          preserveAspectRatio="xMidYMax meet"
        >
          <defs>
            <filter id="sketch" x="-5%" y="-5%" width="110%" height="110%">
              <feTurbulence type="fractalNoise" baseFrequency="0.04 0.07" numOctaves="3" seed="8" result="noise" />
              <feDisplacementMap in="SourceGraphic" in2="noise" scale="1.6" xChannelSelector="R" yChannelSelector="G" />
            </filter>
          </defs>
          <g filter="url(#sketch)" fill="none" strokeLinecap="round" strokeLinejoin="round">
            {/* Distant gentle mountain lines */}
            <path
              d="M-20 420 C30 310 70 270 130 290 C160 300 180 320 220 295 C270 265 300 230 360 245 C400 255 420 280 460 260 C510 235 540 210 600 230 C650 248 670 270 720 255 C760 242 790 260 830 250"
              stroke="rgba(43,70,53,0.06)"
              strokeWidth="1.2"
            />
            <path
              d="M-20 430 C20 340 55 300 110 315 C145 325 170 345 210 325 C255 302 285 268 340 280 C375 288 400 308 440 290 C488 268 515 245 570 262 C618 278 640 298 685 280 C725 264 760 278 830 268"
              stroke="rgba(43,70,53,0.05)"
              strokeWidth="1"
            />
            {/* Soft rolling hills */}
            <path
              d="M-10 450 C80 380 180 360 260 395 C330 425 410 370 490 390 C570 410 660 375 750 410 C790 425 810 435 830 440"
              stroke="rgba(43,70,53,0.04)"
              strokeWidth="1"
            />
            {/* Horizon mist line */}
            <path d="M-10 390 Q200 384 400 387 Q600 390 830 385" stroke="rgba(43,70,53,0.04)" strokeWidth="0.8" />
          </g>
        </svg>
      </div>

      {/* 3. STICKY TOP MONOGRAM CREST BADGE (Appears only on scroll down) */}
      {isOpen && showStickyBadge && (
        <div
          id="mono-badge"
          className="fixed top-2 sm:top-2.5 left-1/2 -translate-x-1/2 z-[900] w-10 h-10 sm:w-11 sm:h-11 rounded-full bg-[#faf5e9]/95 border border-[#2b4635]/35 shadow-[0_2px_12px_rgba(0,0,0,0.18)] backdrop-blur-md flex items-center justify-center transition-all duration-300 hover:scale-105 cursor-pointer animate-fadeIn"
          onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
          title="Blesson & Glinta"
        >
          <svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg" fill="none" className="w-7 h-7 sm:w-8 sm:h-8">
            <circle cx="50" cy="50" r="48" fill="#2b4635" stroke="rgba(43,70,53,.4)" strokeWidth="1" />
            <text x="33" y="62" textAnchor="middle" fontFamily="'Italiana', serif" fontSize="32" fill="#a07820">
              B
            </text>
            <text x="50" y="62" textAnchor="middle" fontFamily="'Playfair Display', serif" fontSize="18" fill="rgba(255,255,255,.85)" fontStyle="italic">
              &amp;
            </text>
            <text x="67" y="62" textAnchor="middle" fontFamily="'Italiana', serif" fontSize="32" fill="#a07820">
              G
            </text>
          </svg>
        </div>
      )}

      {/* Top-Right Live Green Indicator Dot (Only on scroll with sticky badge) */}
      {isOpen && showStickyBadge && (
        <div
          className="fixed top-2.5 right-3.5 sm:right-6 w-3 h-3 rounded-full bg-[#9dbe43] border border-[#2b4635] shadow-[0_0_8px_rgba(157,190,67,0.7)] pointer-events-none z-[900] animate-fadeIn"
          aria-hidden="true"
        />
      )}

      {/* 4. FLOATING ROSE PETALS */}
      <PetalField />

      {/* 5. OPENING ENVELOPE / COVER CARD */}
      <OpeningCover isOpen={isOpen} onOpen={handleOpenInvitation} />

      {/* 6. FLOATING BGM AUDIO CONTROLLER AT BOTTOM RIGHT */}
      {isOpen && <MusicController />}

      {/* 7. LUXURY CARD SHEET COLUMN MATCHING SARA WEDS ISAAC */}
      <div className="relative z-10 mx-auto max-w-xl min-h-screen bg-[#faf5e9]/25 shadow-2xl border-x border-[rgba(160,120,32,0.25)]">
        <main>
          {/* 1. Regal Arch Hero */}
          <HeroSection onScrollToDetails={() => scrollToSection('countdown-section')} />

          {/* 2. Date Bar, 3-Column Numbers & His Word Countdown */}
          <div id="countdown-section">
            <CountdownSection />
          </div>

          {/* 3. The Couple & Malta to Canada Love Story */}
          <div id="story-artwork">
            <StoryArtworkSection />
          </div>

          {/* 4. The Occasion: Stay Samara, Date, Directions & Calendar */}
          <EventDetailsSection />

          {/* 5. The Gallery: Center-Peek 3D Carousel with Likes */}
          <div id="gallery">
            <GallerySection />
          </div>

          {/* 6. Meet Our Families */}
          <ParentsSection />

          {/* 7. RSVP Card with WhatsApp & Firestore */}
          <div id="rsvp">
            <RsvpSection />
          </div>

          {/* 8. Wishes Wall with Realtime Firestore sync */}
          <div id="wishes">
            <WishesGuestbook />
          </div>

          {/* 9. Contact, Monogram Crest & Discreet Bottom Admin Portal */}
          <BibleVerseFooter />
        </main>
      </div>
    </div>
  );
}
