import { GalleryPhoto, WeddingDetails, WishEntry } from '../types';

export const WEDDING_DETAILS: WeddingDetails = {
  groom: {
    fullName: 'Blesson Abraham',
    fatherName: 'Punnose Abraham',
    motherName: 'Lalitha Punnose',
    origin: 'Kottayam, Kerala',
  },
  bride: {
    fullName: 'Glinta Jofna',
    fatherName: 'Felix Joseph',
    motherName: 'Usha Joseph',
    origin: 'Kottayam, Kerala',
  },
  quote: "From little hello’s to endless talks what started as a simple connection, slowly became our forever affection.",
  dateStr: 'Monday, 7 December 2026',
  targetDateISO: '2026-12-07T11:30:00+05:30',
  venueName: 'Stay Samara',
  venueLocation: 'Kottayam, Kerala',
  holyWeddingTime: '11:30 AM',
  mapQuery: 'Stay+Samara+Kottayam+Kerala',
};

// Signature couple love-story artwork (Malta to Canada)
export const STORY_ARTWORK = {
  url: '/assets/aistudio/IMG-20261108-WA0198_dc4d8a99.jpg',
  title: 'Malta to Canada',
  subtitle: 'From Little Hellos to Forever Affection',
  quote: 'From little hello’s to endless talks what started as a simple connection, slowly became our forever affection.',
  caption: 'Across continents, time zones, and endless messages — our forever began with a simple hello.',
};

// Gallery Photos without IMG_1974 as requested
export const GALLERY_PHOTOS: GalleryPhoto[] = [
  {
    id: 'photo-2',
    url: '/assets/aistudio/IMG_2020_5623191d.PNG',
    title: 'Cherished Moments',
    caption: 'Together Forever',
    tag: 'Together Forever',
  },
  {
    id: 'photo-3',
    url: '/assets/aistudio/IMG_2023_0404ac9a.PNG',
    title: 'Aisle of Dreams',
    caption: 'Under Sunny Skies',
    tag: 'Aisle of Dreams',
  },
  {
    id: 'photo-4',
    url: '/assets/aistudio/IMG_2027_b8243027.PNG',
    title: 'Pure Smiles',
    caption: 'Peace and Happiness',
    tag: 'Pure Smiles',
  },
];

// Both authentic contact numbers are WhatsApp numbers
export const WEDDING_CONTACTS = [
  {
    id: 'c1',
    name: 'Blesson & Glinta',
    number: '+91 90722 56228',
    cleanNumber: '919072256228',
    label: 'WHATSAPP',
    isWhatsApp: true,
  },
  {
    id: 'c2',
    name: 'Blesson & Glinta',
    number: '+91 9539577574',
    cleanNumber: '919539577574',
    label: 'WHATSAPP',
    isWhatsApp: true,
  },
];

export const INITIAL_WISHES: WishEntry[] = [];
