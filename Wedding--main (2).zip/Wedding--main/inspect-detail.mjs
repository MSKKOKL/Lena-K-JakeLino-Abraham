import fs from 'fs';

const html = fs.readFileSync('/tmp/sara_isaac.html', 'utf8');

// Find all sections or main components
const sectionRegex = /<(section|div)[^>]*(id|class)="([^"]*(sec|section|wrap|hero|landing|invite|gallery|dress|family|rsvp|wishes|wall|reach|explore|foot)[^"]*)"[^>]*>/gi;
const matches = [...html.matchAll(sectionRegex)];
console.log('Matching sections/divs:');
for (const m of matches) {
  console.log(`${m[1]} ${m[2]}="${m[3]}"`);
}

// Check how BGM audio is defined
const bgmMatch = html.match(/id="bgm[^>]*>[\s\S]*?<\/div>/);
if (bgmMatch) console.log('BGM markup:', bgmMatch[0]);

const audioTag = html.match(/<audio[\s\S]*?<\/audio>/);
if (audioTag) console.log('Audio tag:', audioTag[0]);

const scriptAudio = html.match(/bgmAudio[\s\S]{0,300}/);
if (scriptAudio) console.log('Script audio:', scriptAudio[0]);
